<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/userslist', 'FormController@index');
Route::get('/usersform', 'FormController@form');
Route::post('/saveform', 'FormController@store');
Route::get('/editusers/{id}', 'FormController@edit');
Route::get('/deleteusers/{id}', 'FormController@delete');
Route::post('/countrystate', 'FormController@getStates');
Route::delete('/deleteallusers', 'FormController@deleteAll');

Route::get('/ctrylist', 'CountryController@indexctry');
Route::get('/ctryform', 'CountryController@formctry');
Route::post('/savectry', 'CountryController@storectry');
Route::get('/editctry/{ctryid}','CountryController@editctry');
Route::get('/deletectry/{ctryid}', 'CountryController@deletectry');

Route::get('/statelist', 'StateController@indexstate')->name('statelist');
Route::get('/stateform', 'StateController@formstate');
Route::post('/savestate', 'StateController@storestate');
Route::get('/editstate/{stateid}','StateController@editstate');
Route::get('/deletestate/{statid}', 'StateController@deletestate');





Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

