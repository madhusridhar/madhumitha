<!DOCTYPE html>
<html><head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css">

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<style type="text/css">
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>
	</head>
<body>
<ul>
  <li><a class="active" href="<?php echo e(url('/')); ?>">Home</a></li>
  <?php if(Auth::check()): ?>
  <li><a href="<?php echo e(url('/userslist')); ?>">Users</a></li>
  <li><a href="<?php echo e(url('/ctrylist')); ?>">Country</a></li>
  <li><a href="<?php echo e(url('/statelist')); ?>">State</a></li>
  <li><a href="<?php echo e(url('/registerlist')); ?>">Register user</a></li>
  <li><a href="<?php echo e(url('/logout')); ?>">Logout</a></li>
  <!-- <li><a href="<?php echo e(url('/login')); ?>">Login</a></li> -->
 <?php endif; ?>
  
  
</ul>

<?php /**PATH C:\xampp\htdocs\laravel\resources\views/layouts/header.blade.php ENDPATH**/ ?>