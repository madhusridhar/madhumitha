<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!DOCTYPE html>
<html><head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Add Details</title>
	
	
	<style type="text/css">
		label
		{
			display: inline-block;
			width: 250px;
		}
	span {
			display:block;
			color:red;
		}	

		div
		{
			margin-top: 10px;
		}
		.center
		{
            display: flex;
			margin: 0 auto;
			justify-content: center;
			align-items: center;
			max-width: 100%;
		}
		/* .btn
		{
			text-align: center;
			margin-top: 10px;
		} */
		#button1{
			padding: 8px 20px;
			display:inline-block;
		}
		#button2{
    	text-decoration: none;
		padding: 8px 20px;
		color: black;
		display:inline-block;
		}
		#container{
    	text-align: center;
		}

		input,select,textarea
		{
		   outline: none;
		}
		.error
		{
			   display:block;
			   margin-top: 10px;
			   color: red;
			   display: none;
			 
		}
        select
		{
			width: 100px;
		}
		#success        /*  //from the postdata*/
		{
			text-align: center;
			color: green;
			font-size: 20px;

		}
		#errmsg{
			color:red;
		}
		


	</style>
</head>
<body cz-shortcut-listen="true">
	<div class="center">
		<form method="post">
		<h1>State Details</h1>
	<div>
		<label>Country</label>
			<select name="country" id="country" name="ctry_id">
			 
                            <?php if(count($country)): ?>
                                <option value="" selected>Select country</option>
                                <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php ($selected=""); ?>
                                    <?php ($countryId = isset($userdata['stat_ctry_id']) ? $userdata['stat_ctry_id']: ''); ?>

                                    <?php if($countryId !=''): ?>
                                        <?php if($row['ctry_id']==$userdata['stat_ctry_id']): ?>
                                            <?php ($selected="selected"); ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <option value="<?php echo e($row['ctry_id']); ?>" <?php echo e($selected); ?>><?php echo e($row['ctry_name']); ?> </option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="">No options</option>
                            <?php endif; ?>
                        </select>
				
			<span id="error-data-country"></span>	
</div>	
<div>
			<label>State</label>
			<input type="text" id="state" name="state" value="<?php echo e(( isset ($userdata['stat_name'])?$userdata['stat_name']:"")); ?>">
			
				
				<span id="error-data-state"></span>	
</div>	
<div class="btn">
				<input type="submit" name="submit" value="Submit" id="button1">
				<button type="cancel"><a id="button2" href="<?php echo e(url('/statelist')); ?>">Cancel</a>
			</div>
			<input type="hidden" name="stat_id" id="stat_id" value="<?php echo e(( isset ($userdata['stat_id'])?$userdata['stat_id']:"")); ?>">
		</form>
	</div>
	<div id="successdiv"></div>

<script>
                        $("form").submit(function(){
                            var state=$("#state").val();
                            var country=$("#country").val();
                            
					if(state==""){
						$("#error-data-state").html("please enter state");
                                }
						else{
								$("#error-data-state").html("");

								}

					if(country==""){
						$("#error-data-country").html("please enter country");
                                }
					else{
						$("#error-data-country").html("");

						$.ajax({
									url: "<?php echo e(url("savestate")); ?>",
									method: "POST",
									data: {  "_token": "<?php echo csrf_token(); ?>",
											state:state,
											ctry_id:$("#country").val(),
											stat_id:$("#stat_id").val()
											 },
									dataType: "json",

								success: function(result){
									if (result.status==1){
									$("#successdiv").html(result.messege);
									window.location="<?php echo e("statelist"); ?>";
									// alert(result.status);

											}
									if(result.status==0){
									$("#success").html(result.messege);

											}
											
            						}
      
								});//ajax end


								}
                                return false;
					});//submit ends
                
	


</script>
</body>
</html>
	<?php /**PATH C:\xampp\htdocs\laravel\resources\views/state\formstate.blade.php ENDPATH**/ ?>