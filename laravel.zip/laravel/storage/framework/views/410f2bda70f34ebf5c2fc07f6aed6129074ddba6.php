<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	
	<title>Home</title>
	<style type="text/css">
		*
		{
			margin: 0;
			padding: 0;
		}
		.head
		{
			height: 50px;
			background-color: #3492eb;
		}
		.pd_div
		{
		    background-color: #e7e7e7;
		    height: 50px;
		    display: flex;
		    justify-content: space-between;
		    align-content: center;
		    align-items: center;	   
		}
		.add_user
		{
			 text-decoration: none;
			 background-color: #14c71a;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
		}
		.heading
		{
			margin-left: 20px;
			font-size: 24px;
			font-weight: bold;
		}
		.filter_search
		{
            height: 80px;
            /*background-color: #abdc;*/
            display: flex;
            align-items: center;
            float: right;
            margin-right: 20px;


            /*justify-content: space-between;*/

		}
		.search
		{
			outline: none;
			padding: 5px 8px;
		}
		.search_btn
		{
			padding: 5px 8px;
			cursor: pointer;
		}
		.search_country,.search_state
		{
				padding: 7px 8px;
				cursor: pointer;
				width: 100px;
				outline: none;
		}
		.dlt_btn{
			cursor: pointer;
			text-decoration: none;
			 background-color: red;
			 padding: 8px 20px;
			 /* margin: 0px 20px; */
			 margin-left: 1240px;
			 color: white;
			 border-radius: 20px;
			
			
		}
		.clear
		{
			clear: both;
			display: flex;
			justify-content: center;
		}
		#list 
		{
		  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		  border-collapse: collapse;
		  width: 100%;
        }

        #list td, #list th 
        {
		  border: 1px solid #ddd;
		  padding: 8px;
		  text-align: center;
        }	

        #list th 
        {
          text-align: center;
        }

        #list tr:nth-child(even)
        {
        	background-color: #f2f2f2;
        }

		#list tr:hover 
		{
			background-color: #ddd;
			cursor: pointer;
		}

		#list th 
		{
		  padding-top: 12px;
		  padding-bottom: 12px;
		  text-align: center;
		  background-color: #4CAF50;
		  color: white;
		}
		.pagelist
		{
             text-decoration: none;
             background-color: #182c4d;
             color: white;
             padding: 3px 10px;
		}
		.pagination {
 	 		display: inline-block;
				}

		.pagination a {
 	 	color: black;
  		float: left;
 	 	padding: 8px 16px;
  		text-decoration: none;
		}

		</style>
	<div class="head">
		
	</div>

	<div style="margin:10px;" class="pd_div">
	<p class="heading">Countrylist</p>
	<a  class="add_user" href="<?php echo e(url('/ctryform')); ?>">Add Country</a>
		</div>
		<div style="margin:10px;">
		</div>

	<div class="clear">
</div>
<div id="target-content"><table id="list">
<tr>


	    <thead>
		 <tr>
			<th>Country</th>
            <th>Edit</th>
			<th>Delete</th>
				
			</tr>
			
		</thead>	
		
	<tbody id="tabledata">
	 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		
		   <tr>
		   		<td><?php echo e($tr['ctry_name']); ?></td>
		   	    <td><a href="<?php echo e(url('editctry',$tr['ctry_id'])); ?>">edit</a></td>
		   		<td><a href="#" class="delete" onclick="deletefun(<?php echo e($tr['ctry_id']); ?>)">delete</a></td>
            </tr> 
		   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		   </div>

 </tbody>
 </table>
 <script type="text/javascript">

 		 			$(document).ready(function() {
  		  			$('#list').DataTable();
					} );
 

</script>
<script>
		$(document).ready(function() {

				
//bulk delete

				$('#blkdelete').click(function(){
 					var  allVals = [];
						$(':checkbox:checked').each(function(i){
							allVals[i] = $(this).val();
					 }); 
			 //alert(id); return false;
 				if( allVals.length === 0)
		 		{
 				alert("Please Select Checkbox");
				 return false;
 				}
				if(confirm("Are you sure to delete?"))
 			
			 	{
					var join_selected_values = allVals.join(",");

 		
 		$.ajax({
 							url: "<?php echo e(url("deleteallusers")); ?>",
							type: 'DELETE',
							headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
							data: 'id='+join_selected_values,
							success: function (data)
							{
								if (data['success']) {
                                $(".sub_chk:checked").each(function() {
                                    $(this).parents("tr").remove();
                                });
                                alert(data['success']);
                            } else if (data['error']) {
                                alert(data['error']);
                            } else {
                                alert('Whoops Something went wrong!!');
                            }
                        },
						error: function (data) {
                            alert(data.responseText);
                        }
 							});//ajax ends

					 $.each(allVals, function( index, value ) {
                      $('table tr').filter("[data-row-id='" + value + "']").remove();
					  window.location="<?php echo e(url("ctrylist")); ?>";
                  });


				}//if ends
			 });//click ends
 			
			 

	});  //ready function end

function deletefun(ctryid)
		{
			var ctryid= ctryid;
				// alert(ctryid);
					if(confirm("Are  you want to delete")){

						$.ajax({ 
							url: "<?php echo e(url("deletectry")); ?>"+ "/" + ctryid,
							method: "GET",
						// data: {id:id},
							dataType: "json",
							success: function(result){
							if(result.result==true){
							alert("Record deleted successfully");
							window.location="<?php echo e(url("ctrylist")); ?>";
							}if(result.result==false){
								alert("Record not deleted successfully");
								
							}
							
							}

					});

		
			}
	}
						
        </script>

</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\resources\views/country\indexctry.blade.php ENDPATH**/ ?>