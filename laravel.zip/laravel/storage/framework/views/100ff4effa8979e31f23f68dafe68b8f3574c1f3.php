<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<title>Home</title>
	<style type="text/css">
		*
		{
			margin: 0;
			padding: 0;
		}
		.head
		{
			height: 50px;
			background-color: #3492eb;
		}
		.pd_div
		{
		    background-color: #e7e7e7;
		    height: 50px;
		    display: flex;
		    justify-content: space-between;
		    align-content: center;
		    align-items: center;	   
		}
		.add_user
		{
			 text-decoration: none;
			 background-color: #14c71a;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
		}
		.heading
		{
			margin-left: 20px;
			font-size: 24px;
			font-weight: bold;
		}
		.filter_search
		{
            height: 80px;
            /*background-color: #abdc;*/
            display: flex;
            align-items: center;
            float: right;
            margin-right: 20px;


            /*justify-content: space-between;*/

		}
		.search
		{
			outline: none;
			padding: 5px 8px;
		}
		.search_btn
		{
			padding: 5px 8px;
			cursor: pointer;
		}
		.search_country,.search_state
		{
				padding: 7px 8px;
				cursor: pointer;
				width: 100px;
				outline: none;
		}
		.dlt_btn{
			cursor: pointer;
			text-decoration: none;
			 background-color: red;
			 padding: 8px 20px;
			 /* margin: 0px 20px; */
			 margin-left: 1240px;
			 color: white;
			 border-radius: 20px;
			
			
		}
		.clear
		{
			clear: both;
			display: flex;
			justify-content: center;
		}
		#list 
		{
		  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		  border-collapse: collapse;
		  width: 100%;
        }

        #list td, #list th 
        {
		  border: 1px solid #ddd;
		  padding: 8px;
		  text-align: center;
        }	

        #list th 
        {
          text-align: center;
        }

        #list tr:nth-child(even)
        {
        	background-color: #f2f2f2;
        }

		#list tr:hover 
		{
			background-color: #ddd;
			cursor: pointer;
		}

		#list th 
		{
		  padding-top: 12px;
		  padding-bottom: 12px;
		  text-align: center;
		  background-color: #4CAF50;
		  color: white;
		}
		.pagelist
		{
             text-decoration: none;
             background-color: #182c4d;
             color: white;
             padding: 3px 10px;
		}
		.pagination {
 	 		display: inline-block;
				}

		.pagination a {
 	 	color: black;
  		float: left;
 	 	padding: 8px 16px;
  		text-decoration: none;
		}

		</style>
        <div class="head">
		
        </div>
    
        <div style="margin:10px;" class="pd_div">
        <p class="heading">Register User</p>
       
            </div>
           
    
        <div class="clear">
    </div>
    <div id="target-content"><table id="list">
    
    <thead>
		 <tr>
               <th> Name</th>
				<th>Email</th>
                <th>Edit</th>
				<th>Delete</th>
				
			</tr>
			
		</thead>
        	
	   <tbody id="tabledata">
	  
	
	  
	   <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		
		     <tr>
             <td><?php echo e($tr['name']); ?></td>
		   	<td><?php echo e($tr['email']); ?></td> 
			   <?php if(Auth::user()->id==$tr['id']): ?>         
		   		<td><a href="<?php echo e(url('editregister',$tr['id'])); ?>">edit</a></td>
		   		<td><a href="#" class="delete" onclick="deletefun(<?php echo e($tr['id']); ?>)">delete</a></td>
				 <?php endif; ?>   

		    </tr> 
		   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  
		   </div>

 </tbody>
 </table>
 <script>
 function deletefun(id)
		{
			var id=id;
				// alert(id);
					if(confirm("Are  you want to delete")){

						$.ajax({ 
							url: "<?php echo e(url("deleteregister")); ?>"+ "/" + id,
							method: "GET",
						// data: {id:id},
							dataType: "json",
							success: function(result){
							window.location="<?php echo e(url("registerlist")); ?>";
						// alert("Record deleted successfully");
							}

					});

		
			}
	}
 </script>
</body>
</html>		<?php /**PATH C:\xampp\htdocs\laravel\resources\views/register\indexregister.blade.php ENDPATH**/ ?>