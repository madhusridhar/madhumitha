<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!DOCTYPE html>
<html><head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Add Details</title>
	
	
	<style type="text/css">
		label
		{
			display: inline-block;
			width: 250px;
		}
	span {
			display:block;
			color:red;
		}	

		div
		{
			margin-top: 10px;
		}
		.center
		{
            display: flex;
			margin: 0 auto;
			justify-content: center;
			align-items: center;
			max-width: 100%;
		}
		/* .btn
		{
			text-align: center;
			margin-top: 10px;
		} */
		#button1{
			padding: 8px 20px;
			display:inline-block;
		}
		#button2{
    	text-decoration: none;
		padding: 8px 20px;
		color: black;
		/* margin-top:10px; */
		display:inline-block;
		}
		#container{
    	text-align: center;
		}

		input,select,textarea
		{
		   outline: none;
		}
		.error
		{
			   display:block;
			   margin-top: 10px;
			   color: red;
			   display: none;
			 
		}
        select
		{
			width: 100px;
		}
		#success        /*  //from the postdata*/
		{
			text-align: center;
			color: green;
			font-size: 20px;

		}
		#errmsg{
			color:red;
		}
		


	</style>
</head>
<body cz-shortcut-listen="true">
	<div class="center">
		<form method="post">
		<h1>Personal Details</h1>
		<span id="errmsg"></span>
	
	

<div>
			<label>Name</label>
			<input type="text" name="name" id="name" value="<?php echo e((isset($userdata['name'])? $userdata['name']:"")); ?>">
			<span id="error-data-name"></span>
				
</div>

<div>
			<label>Email</label>
			<input type="text" name="email" id="email" value="<?php echo e((isset($userdata['email'])? $userdata['email']:"")); ?>">
			<span id="error-data-email"></span>
				
			
</div>
<div id="container">
    <button type="submit" name="submit"  id="button1">Submit</button>
	
	
    <button type="cancel"><a id="button2" href="<?php echo e(url('/registerlist')); ?>">Cancel</a>
</div>

	<input type="hidden" name="id" id="id" value="<?php echo e(( isset ($userdata['id'])?$userdata['id']:"")); ?>">
		</form>
	</div>
	<div id="successdiv"></div>
    <script>
                        $("form").submit(function(){

					var name=$("#name").val();
                    var email=$("#email").val();
                    var fname = /^[A-Za-z ]+$/;  
							if(name==""){
							$("#error-data-first").html("please enter Firstname");
							
							 }
					
							else if(!fname.test(name)){
							$("#error-data-name").html("please enter valid name");
								}
							else{
							$("#error-data-name").html("");
								}

					

					var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  
						  if(email==""){
						  $("#error-data-email").html("please enter email");
						  }
						  else if(!mailformat.test(email)){
						  $("#error-data-email").html("please enter  valid email");	
						   }
						  else{
								$("#error-data-email").html("");
								}
                                

                         $.ajax({
									url:"<?php echo e(url("saveregister")); ?>",
									method: "POST",
									data: {  "_token": "<?php echo csrf_token(); ?>",
											name:name,
											email:email,
                                            id:$("#id").val()
											 },
									dataType: "json",

								success: function(result){
									if (result.result==1){
									$("#successdiv").html(result.messege);
									window.location="<?php echo e(url("registerlist")); ?>";
									// alert(result.status);

											}
									if(result.result==0){
									$("#success").html(result.messege);

											}
											
            						}
      
								});//ajax ends
							
				

						
						return false;
					});//submit ends
                


</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\resources\views/register\formregister.blade.php ENDPATH**/ ?>