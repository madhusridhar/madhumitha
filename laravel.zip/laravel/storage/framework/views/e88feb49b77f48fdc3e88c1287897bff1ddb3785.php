<!DOCTYPE html>
<!-- saved from url=(0022)http://localhost/task/ -->
<html><head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css">

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">.

	
	<title>Home</title>
	<style type="text/css">
		*
		{
			margin: 0;
			padding: 0;
		}
		.head
		{
			height: 50px;
			background-color: #3492eb;
		}
		.pd_div
		{
		    background-color: #e7e7e7;
		    height: 50px;
		    display: flex;
		    justify-content: space-between;
		    align-content: center;
		    align-items: center;	   
		}
		.add_user
		{
			 text-decoration: none;
			 background-color: #14c71a;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
		}
		.heading
		{
			margin-left: 20px;
			font-size: 24px;
			font-weight: bold;
		}
		.filter_search
		{
            height: 80px;
            /*background-color: #abdc;*/
            display: flex;
            align-items: center;
            float: right;
            margin-right: 20px;


            /*justify-content: space-between;*/

		}
		.search
		{
			outline: none;
			padding: 5px 8px;
		}
		.search_btn
		{
			padding: 5px 8px;
			cursor: pointer;
		}
		.search_country,.search_state
		{
				padding: 7px 8px;
				cursor: pointer;
				width: 100px;
				outline: none;
		}
		.dlt_btn{
			cursor: pointer;
			text-decoration: none;
			 background-color: red;
			 padding: 8px 20px;
			 /* margin: 0px 20px; */
			 margin-left: 1240px;
			 color: white;
			 border-radius: 20px;
			
			
		}
		.clear
		{
			clear: both;
			display: flex;
			justify-content: center;
		}
		#list 
		{
		  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		  border-collapse: collapse;
		  width: 100%;
        }

        #list td, #list th 
        {
		  border: 1px solid #ddd;
		  padding: 8px;
		  text-align: center;
        }	

        #list th 
        {
          text-align: center;
        }

        #list tr:nth-child(even)
        {
        	background-color: #f2f2f2;
        }

		#list tr:hover 
		{
			background-color: #ddd;
			cursor: pointer;
		}

		#list th 
		{
		  padding-top: 12px;
		  padding-bottom: 12px;
		  text-align: center;
		  background-color: #4CAF50;
		  color: white;
		}
		.pagelist
		{
             text-decoration: none;
             background-color: #182c4d;
             color: white;
             padding: 3px 10px;
		}
		.pagination {
 	 		display: inline-block;
				}

		.pagination a {
 	 	color: black;
  		float: left;
 	 	padding: 8px 16px;
  		text-decoration: none;
		}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
		</style>
	</head>
<body cz-shortcut-listen="true">
	<div class="head">
		
	</div>

	<div style="margin:10px;" class="pd_div">
	<p class="heading">Personal Details</p>
	<a  class="add_user" href="<?php echo e(url('/usersform')); ?>">Add User</a>
		</div>
<ul>
  <li><a class="active" href="#home">Home</a></li>
  <li><a href="<?php echo e(url('/userslist')); ?>">Page 1</a></li>
  <li><a href="#">Page 2</a></li>
  
</ul>
		<div style="margin:10px;">
		<a class="dlt_btn" id="blkdelete">Delete</a>
		</div>

	<div class="clear">
</div>
<div id="target-content"><table id="list">

	    <thead>
		 <tr>
			
				<th><input type="checkbox" class= "checked_all"></th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Email</th>
				<th>Gender</th>
				<th>Mobile Number</th>
				<!-- <th>Address 1</th>
				<th>Address 2</th> -->
				<th>Country</th>
				<th>State</th>
				<th>City</th>
				<th>Pincode</th>
				<th>Edit</th>
				<th>Delete</th>
				
			</tr>
			
		</thead>	
		
	   <tbody id="tabledata">
	  <div class="pagination">
	
	   
	   <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		
		     <tr>
		    	<td><input type="checkbox" class="checkbox"  value="<?php echo e($tr['user_id']); ?>"></td>


		

				<td><?php echo e($tr['user_first_name']); ?></td>
		   		<td><?php echo e($tr['user_last_name']); ?></td>
		   		<td><?php echo e($tr['usser_email']); ?></td>  	
				   <td>
				    <?php if($tr['user_gender']== '2'): ?>
        				<?php echo e("FEMALE"); ?>

    					
    				<?php else: ?> 
        		<?php echo e("MALE"); ?>

    		 <?php endif; ?>

				<td><?php echo e($tr['user_mobile_no']); ?></td>
		   		<!-- <td><?php echo e($tr['user_addr1']); ?></td> 
		   		<td><?php echo e($tr['user_addr2']); ?></td> -->
		   		<td><?php echo e($tr['ctry_name']); ?></td>
		   		<td><?php echo e($tr['stat_name']); ?></td> 
		   		<td><?php echo e($tr['user_city']); ?></td>
		   		<td><?php echo e($tr['user_pincode']); ?></td>

		   		<td><a href="<?php echo e(url('editusers',$tr['user_id'])); ?>">edit</a></td>
		   		<td><a href="#" class="delete" onclick="deletefun(<?php echo e($tr['user_id']); ?>)">delete</a></td>
				   

		    </tr> 
		   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		   </div>

 </tbody>
 </table>
 <script type="text/javascript">

 		 			$(document).ready(function() {
  		  			$('#list').DataTable();
					} );
 

</script>
<script>
		$(document).ready(function() {

					$('.checked_all').on('change', function() {     
               		 $('.checkbox').prop('checked', $(this).prop("checked"));              
        					});
        //deselect "checked all", if one of the listed checkbox product is unchecked amd select "checked all" if all of the listed checkbox product is checked
        			$('.checkbox').change(function(){
					 
            		if($('.checkbox:checked').length == $('.checkbox').length){
                  	 $('.checked_all').prop('checked',true);

           			 }else{
                  	 $('.checked_all').prop('checked',false);
            }
        });
//bulk delete

				$('#blkdelete').click(function(){
 					var  allVals = [];
						$(':checkbox:checked').each(function(i){
							allVals[i] = $(this).val();
					 }); 
			 //alert(id); return false;
 				if( allVals.length === 0)
		 		{
 				alert("Please Select Checkbox");
				 return false;
 				}
				if(confirm("Are you sure to delete?"))
 			
			 	{
					var join_selected_values = allVals.join(",");

 		
 		$.ajax({
 							url: "<?php echo e(url("deleteallusers")); ?>",
							type: 'DELETE',
							headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
							data: 'id='+join_selected_values,
							success: function (data)
							{
								if (data['success']) {
                                $(".sub_chk:checked").each(function() {
                                    $(this).parents("tr").remove();
                                });
                                alert(data['success']);
                            } else if (data['error']) {
                                alert(data['error']);
                            } else {
                                alert('Whoops Something went wrong!!');
                            }
                        },
						error: function (data) {
                            alert(data.responseText);
                        }
 							});//ajax ends

					 $.each(allVals, function( index, value ) {
                      $('table tr').filter("[data-row-id='" + value + "']").remove();
					  window.location="<?php echo e(url("userslist")); ?>";
                  });


				}//if ends
			 });//click ends
 			
			 



	

	$( "#search_btn" ).click(function() {
		
						var country=$("#search_input_country").val();
						// alert( country );
						var state=	$("#state").val();
						var input=	$("#search_input").val();
						$.ajax({ 
									url: "searchlist.php",
									method: "POST",
									data: { country: country,
											state:state,
											input:input
											},
									dataType: "html",
									success: function(result){
									$("#tabledata").html(result);
            						}
      
								});


			});

	});  //ready function end

function deletefun(id)
		{
			var id=id;
				// alert(id);
					if(confirm("Are  you want to delete")){

						$.ajax({ 
							url: "<?php echo e(url("deleteusers")); ?>"+ "/" + id,
							method: "GET",
						// data: {id:id},
							dataType: "json",
							success: function(result){
							window.location="<?php echo e(url("userslist")); ?>";
						// alert("Record deleted successfully");
							}

					});

		
			}
	}
						
        </script>

</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\resources\views/index.blade.php ENDPATH**/ ?>