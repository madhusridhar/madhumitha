<!DOCTYPE html>
<html><head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css">

<meta name="csrf-token" content="{{ csrf_token() }}">

<style type="text/css">
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>
	</head>
<body>
<ul>
  <li><a class="active" href="{{url('/')}}">Home</a></li>
  @if(Auth::check())
  <li><a href="{{url('/userslist')}}">Users</a></li>
  <li><a href="{{url('/ctrylist')}}">Country</a></li>
  <li><a href="{{url('/statelist')}}">State</a></li>
  <li><a href="{{url('/registerlist')}}">Register user</a></li>
  <li><a href="{{url('/logout')}}">Logout</a></li>
  <!-- <li><a href="{{url('/login')}}">Login</a></li> -->
 @endif
  
  
</ul>

