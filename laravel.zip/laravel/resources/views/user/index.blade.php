@include('layouts.header')

	
	<title>Home</title>
	<style type="text/css">
		*
		{
			margin: 0;
			padding: 0;
		}
		.head
		{
			height: 50px;
			background-color: #3492eb;
		}
		.pd_div
		{
		    background-color: #e7e7e7;
		    height: 50px;
		    display: flex;
		    justify-content: space-between;
		    align-content: center;
		    align-items: center;	   
		}
		.add_user
		{
			 text-decoration: none;
			 background-color: #14c71a;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
		}
		.heading
		{
			margin-left: 20px;
			font-size: 24px;
			font-weight: bold;
		}
		.filter_search
		{
            height: 80px;
            /*background-color: #abdc;*/
            display: flex;
            align-items: center;
            float: right;
            margin-right: 20px;


            /*justify-content: space-between;*/

		}
		.search
		{
			outline: none;
			padding: 5px 8px;
		}
		.search_btn
		{
			padding: 5px 8px;
			cursor: pointer;
		}
		.search_country,.search_state
		{
				padding: 7px 8px;
				cursor: pointer;
				width: 100px;
				outline: none;
		}
		.dlt_btn{
			cursor: pointer;
			text-decoration: none;
			 background-color: red;
			 padding: 8px 20px;
			 /* margin: 0px 20px; */
			 margin-left: 1240px;
			 color: white;
			 border-radius: 20px;
			
			
		}
		.clear
		{
			clear: both;
			display: flex;
			justify-content: center;
		}
		#list 
		{
		  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		  border-collapse: collapse;
		  width: 100%;
        }

        #list td, #list th 
        {
		  border: 1px solid #ddd;
		  padding: 8px;
		  text-align: center;
        }	

        #list th 
        {
          text-align: center;
        }

        #list tr:nth-child(even)
        {
        	background-color: #f2f2f2;
        }

		#list tr:hover 
		{
			background-color: #ddd;
			cursor: pointer;
		}

		#list th 
		{
		  padding-top: 12px;
		  padding-bottom: 12px;
		  text-align: center;
		  background-color: #4CAF50;
		  color: white;
		}
		.pagelist
		{
             text-decoration: none;
             background-color: #182c4d;
             color: white;
             padding: 3px 10px;
		}
		.pagination {
 	 		display: inline-block;
				}

		.pagination a {
 	 	color: black;
  		float: left;
 	 	padding: 8px 16px;
  		text-decoration: none;
		}

		</style>
	<div class="head">
		
	</div>

	<div style="margin:10px;" class="pd_div">
	<p class="heading">Personal Details</p>
	<a  class="add_user" href="{{url('/usersform')}}">Add User</a>
		</div>
		<div style="margin:10px;">
		<a class="dlt_btn" id="blkdelete">Delete</a>
		</div>

	<div class="clear">
</div>
<div id="target-content"><table id="list">

	    <thead>
		 <tr>
			
				<th><input type="checkbox" class= "checked_all"></th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Email</th>
				<th>Gender</th>
				<th>Mobile Number</th>
				<!-- <th>Address 1</th>
				<th>Address 2</th> -->
				<th>Country</th>
				<th>State</th>
				<th>City</th>
				<th>Pincode</th>
				<th>Image</th>
				<th>Edit</th>
				<th>Delete</th>
				
			</tr>
			
		</thead>	
		
	   <tbody id="tabledata">
	  <div class="pagination">
	
	   
	   @foreach($data as $tr)
		
		     <tr>
		    	<td><input type="checkbox" class="checkbox"  value="{{$tr['user_id']}}"></td>


		

				<td>{{ $tr['user_first_name'] }}</td>
		   		<td>{{ $tr['user_last_name'] }}</td>
		   		<td>{{ $tr['usser_email'] }}</td>  	
				   <td>
				    @if($tr['user_gender']== '2')
        				{{ "FEMALE"}}
    					
    				@else 
        		{{"MALE"}}
    		 @endif

				<td>{{ $tr['user_mobile_no'] }}</td>
		   		<!-- <td>{{$tr['user_addr1'] }}</td> 
		   		<td>{{ $tr['user_addr2'] }}</td> -->
		   		<td>{{ $tr['ctry_name'] }}</td>
		   		<td>{{ $tr['stat_name'] }}</td> 
		   		<td>{{ $tr['user_city'] }}</td>
		   		<td>{{ $tr['user_pincode'] }}</td>
				<td>{{ $tr['user_image'] }}</td>

		   		<td><a href="{{ url('editusers',$tr['user_id'])}}">edit</a></td>
		   		<td><a href="#" class="delete" onclick="deletefun({{ $tr['user_id']}})">delete</a></td>
				   

		    </tr> 
		   @endforeach
		   </div>

 </tbody>
 </table>
 <script type="text/javascript">

 		 			$(document).ready(function() {
  		  			$('#list').DataTable();
					} );
 

</script>
<script>
		$(document).ready(function() {

					$('.checked_all').on('change', function() {     
               		 $('.checkbox').prop('checked', $(this).prop("checked"));              
        					});
        //deselect "checked all", if one of the listed checkbox product is unchecked amd select "checked all" if all of the listed checkbox product is checked
        			$('.checkbox').change(function(){
					 
            		if($('.checkbox:checked').length == $('.checkbox').length){
                  	 $('.checked_all').prop('checked',true);

           			 }else{
                  	 $('.checked_all').prop('checked',false);
            }
        });
//bulk delete

				$('#blkdelete').click(function(){
 					var  allVals = [];
						$(':checkbox:checked').each(function(i){
							allVals[i] = $(this).val();
					 }); 
			 //alert(id); return false;
 				if( allVals.length === 0)
		 		{
 				alert("Please Select Checkbox");
				 return false;
 				}
				if(confirm("Are you sure to delete?"))
 			
			 	{
					var join_selected_values = allVals.join(",");

 		
 		$.ajax({
 							url: "{{url("deleteallusers")}}",
							type: 'DELETE',
							headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
							data: 'id='+join_selected_values,
							success: function (data)
							{
								if (data['success']) {
                                $(".sub_chk:checked").each(function() {
                                    $(this).parents("tr").remove();
                                });
                                alert(data['success']);
                            } else if (data['error']) {
                                alert(data['error']);
                            } else {
                                alert('Whoops Something went wrong!!');
                            }
                        },
						error: function (data) {
                            alert(data.responseText);
                        }
 							});//ajax ends

					 $.each(allVals, function( index, value ) {
                      $('table tr').filter("[data-row-id='" + value + "']").remove();
					  window.location="{{url("userslist")}}";
                  });


				}//if ends
			 });//click ends
 			
			 

	});  //ready function end

function deletefun(id)
		{
			var id=id;
				// alert(id);
					if(confirm("Are  you want to delete")){

						$.ajax({ 
							url: "{{url("deleteusers")}}"+ "/" + id,
							method: "GET",
						// data: {id:id},
							dataType: "json",
							success: function(result){
							window.location="{{url("userslist")}}";
						// alert("Record deleted successfully");
							}

					});

		
			}
	}
						
        </script>

</body>
</html>