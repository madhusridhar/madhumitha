
<!DOCTYPE html>
<html><head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Add Details</title>
	
	
	<style type="text/css">
		label
		{
			display: inline-block;
			width: 250px;
		}
	span {
			display:block;
			color:red;
		}	

		div
		{
			margin-top: 10px;
		}
		.center
		{
            display: flex;
			margin: 0 auto;
			justify-content: center;
			align-items: center;
			max-width: 100%;
		}
		.btn
		{
			text-align: center;
			margin-top: 10px;
		}
		input,select,textarea
		{
		   outline: none;
		}
		.error
		{
			   display:block;
			   margin-top: 10px;
			   color: red;
			   display: none;
			 
		}
        select
		{
			width: 100px;
		}
		#success        /*  //from the postdata*/
		{
			text-align: center;
			color: green;
			font-size: 20px;

		}
		#errmsg{
			color:red;
		}
		


	</style>
</head>
<body cz-shortcut-listen="true">
	<div class="center">
		<form method="post">
		<h1>Personal Details</h1>
		<span id="errmsg"></span>
	
	

<div>
			<label>First Name</label>
			<input type="text" name="firstname" id="firstname" value="{{(isset($userdata['user_first_name'])? $userdata['user_first_name']:"")}}">
			<span id="error-data-first"></span>
				
</div>
<div>
			<label>Last Name</label>
			<input type="text" name="lastname" id="lastname" value="{{(isset($userdata['user_last_name'])? $userdata['user_last_name']:"")}}">
			<span id="error-data-last"></span>
				
</div>
<div>
			<label>Email</label>
			<input type="text" name="email" id="email" value="{{(isset($userdata['usser_email'])? $userdata['usser_email']:"")}}">
			<span id="error-data-email"></span>
				
			
</div>
<div>
				
			<label>Gender</label>
			 @if (isset($userdata['user_gender'])&&($userdata['user_gender']==1))
				<input type="radio" name="gender" checked=checked value="1" id="male">male
				
			  @else
				<input type="radio" name="gender"  value="1" id="male">male
			
			@endif 
			@if(isset($userdata['user_gender'])&&($userdata['user_gender']==2))
				<input type="radio" name="gender" checked=checked value="2" id="female">female
				
			@else
				<input type="radio" name="gender"  value="2" id="female">female
			
			@endif
			
			
			<span id="error-data-gender"></span>
				
</div>
<div>
			<label>Mobile Number</label>
			<input type="text" name="number" class="numbersonly" id="number" maxlength="10"  value="{{(isset($userdata['user_mobile_no'])? $userdata['user_mobile_no']:"")}}">
			
				
</div>
<div>
			<label>Address1</label>
			<textarea name="address1" id="address1" >{{(isset($userdata['user_addr1'])? $userdata['user_addr1']:"")}}</textarea>
			<span id="error-data-address1"></span>
				
</div>
 <div>
			<label>Address2</label>
			<textarea name="address2" id="address2" >{{(isset($userdata['user_addr2'])? $userdata['user_addr2']:"")}}</textarea> 
			<span id="error-data-address2"></span>
				
</div> 

<div>
		<label>Country</label>
			<select name="country" id="country">
			 
                            @if(count($country))
                                <option value="" selected>Select country</option>
                                @foreach($country as $row)
                                    @php($selected="")
                                    @php($countryId = isset($userdata['user_ctry_id']) ? $userdata['user_ctry_id']: '')

                                    @if($countryId !='')
                                        @if($row['ctry_id']==$userdata['user_ctry_id'])
                                            @php($selected="selected")
                                        @endif
                                    @endif
                                    <option value="{{$row['ctry_id']}}" {{$selected}}>{{$row['ctry_name']}} </option>

                                @endforeach
                            @else
                                <option value="">No options</option>
                            @endif
                        </select>
				
			<span id="error-data-country"></span>	
</div>	
<div>
			<label>State</label>
			<select name="state" id="state">
			@if(count($state))
                                <option value="" selected>Select state</option>
                                @foreach($state as $row)
                                    @php($selected="")
                                    @php($state = isset($userdata['user_stat_id']) ? $userdata['user_stat_id']: '')

                                    @if($state !='')
                                        @if($row['stat_id']==$userdata['user_stat_id'])
                                            @php($selected="selected")
                                        @endif
                                    @endif
                                    <option value="{{$row['stat_id']}}" {{$selected}}>{{$row['stat_name']}} </option>

                                @endforeach
                            @else
                                <option value="">No options</option>
                            @endif
                        </select>
				
				<span id="error-data-state"></span>	
</div>	
<div>
			<label>City</label>
			<input type="text" name="city" id="city" value="{{(isset($userdata['user_city'])? $userdata['user_city']:"")}}">
			<span id="error-data-city"></span>
				
</div>
<div>
			<label>Pincode</label>
			<input type="text" name="pincode" class="numbersonly" id="pincode"  maxlength="6"  value="{{(isset($userdata['user_pincode'])? $userdata['user_pincode']:"")}}">
			
				
				
</div>
			<div class="btn">
				<input type="submit" name="submit" value="Submit" id="btn">
			</div>
			<input type="hidden" name="userid" id="userid" value="{{( isset ($userdata['user_id'])?$userdata['user_id']:"")}}">
		</form>
	</div>
	<div id="successdiv"></div>
	
	<script>
	 $('body').on('change','#country',function (){
				var countryId=$("#country").val();
				// alert( countryId );

			  $.ajax({
							url: "{{url("countrystate")}}",
							method: "POST",
							data: {"_token": "{!! csrf_token() !!}",
							countryId: countryId
								  },

							dataType:  "JSON",
							success: function(data){
								if(data.result==false){

								$("#state").html("");
								// alert("Not success");
								return false;

								}else{
									$("#state").html(data.states);
									// alert("success");
									
								}					// 	url: "ajaxstate.php",
								
       
								}
							});//ajax ends

			});//function ends
	</script>
	<script>
			$(".numbersonly").keypress(function (e){

				if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        //display error message
       			$("#errmsg").html("numbersonly").show().fadeOut("slow");
               return false;
   			 }
   			
	
			});
	</script>
<script>
                        $("form").submit(function(){

					var firstname=$("#firstname").val();
                    var lastname=$("#lastname").val();
                    var email=$("#email").val();
                    var address1=$("#address1").val();
                    var address2=$("#address2").val();
					var number=$("#number").val();
                    var pincode=$("#pincode").val();
                    var gender= $("input[name='gender']:checked").val();
                    var city=$("#city").val();
                    var state=$("#state").val();
                    var country=$("#country").val();
				
					
					

					
					var fname = /^[A-Za-z ]+$/;  
							if(firstname==""){
							$("#error-data-first").html("please enter Firstname");
							
							 }
					
							else if(!fname.test(firstname)){
							$("#error-data-first").html("please enter valid Firstname");
								}
							else{
							$("#error-data-first").html("");
								}

					var lname = /^[A-Za-z ]+$/;
							if(lastname==""){
							$("#error-data-last").html("please enter Lastname");
							}
							else if(!lname.test(lastname)){
							$("#error-data-last").html("please enter valid Lastname");
							}
							else{
								$("#error-data-last").html("");
                         		 }

					var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  
						  if(email==""){
						  $("#error-data-email").html("please enter email");
						  }
						  else if(!mailformat.test(email)){
						  $("#error-data-email").html("please enter  valid email");	
						   }
						  else{
								$("#error-data-email").html("");
								}

					var phonenum= /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;  
							if(number==""){
						 	$("#error-data-number").html("please enter number");
                            }
							else if(!phonenum.test(number)){
								$("#error-data-number").html("please enter  valid number");	
							}
							else{
								$("#error-data-number").html("");

							}

					var pin= /^[1-9][0-9]{5}$/;  
							if(pincode==""){
						 	$("#error-data-pincode").html("please enter pincode");
                            }
							else if(!pin.test(pincode)){
								$("#error-data-pincode").html("please enter  valid pincode");	
							}
							else{
								$("#error-data-pincode").html("");

							}
						
						 if(address1==""){
						$("#error-data-address1").html("please enter address1");
                        	 }
							 else{
							$("#error-data-address1").html("");
								}

						if(address2==""){
						$("#error-data-address2").html("please enter address2");
                        	 }
							 else{
							$("#error-data-address2").html("");
								}
					 
					 
						
						$("#error-data-gender").html("");
						if (gender === undefined || gender === null) {
						$("#error-data-gender").html("please enter gender");

					}

					var cityname = /^[A-Za-z ]+$/;  
							if(city==""){
							$("#error-data-city").html("please enter city");
							 }
					
							else if(!cityname.test(city)){
							$("#error-data-city").html("please enter valid city");
							}
							else{
							$("#error-data-city").html("");
								}
								
								

					if(state==""){
						$("#error-data-state").html("please enter state");
                                }
						else{
								$("#error-data-state").html("");

								}

					if(country==""){
						$("#error-data-country").html("please enter country");
                                }
					else{
						$("#error-data-country").html("");

								}

						
			  		 $.ajax({
									url:"{{url("saveform")}}",
									method: "POST",
									data: {  "_token": "{!! csrf_token() !!}",
											firstname:firstname,
											lastname:lastname,
											email:email,
											address1:address1,
											address2:address2,
											number:number,
											pincode:pincode,
											gender:gender,
											city:city,
											state:state,
											country:country,
											userid:$("#userid").val()
											 },
									dataType: "json",

								success: function(result){
									if (result.result==1){
									$("#successdiv").html(result.messege);
									window.location="{{url("userslist")}}";
									// alert(result.status);

											}
									if(result.result==0){
									$("#success").html(result.messege);

											}
											
            						}
      
								});//ajax ends
							
				

						
						return false;
					});//submit ends
                
	


</script>
</body>
</html>