@include('layouts.header')
    <!DOCTYPE html>
<html>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
   <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css"/> -->

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js"></script>

    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>

    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

    <title>Add Details</title>


    <style type="text/css">
        label {
            display: inline-block;
            width: 250px;
        }

        span {
            display: block;
            color: red;
        }

        div {
            margin-top: 10px;
        }

        .center {
            display: flex;
            margin: 0 auto;
            justify-content: center;
            align-items: center;
            max-width: 100%;
        }

        /* .btn
        {
            text-align: center;
            margin-top: 10px;
        } */
        #submitButton{
            padding: 8px 20px;
            display: inline-block;
        }

        #button2 {
            text-decoration: none;
            padding: 8px 20px;
            color: black;
            /* margin-top:10px; */
            display: inline-block;
        }

        #container {
            text-align: center;
        }

        input, select, textarea {
            outline: none;
        }

        .error {
            display: block;
            margin-top: 10px;
            color: red;
            display: none;

        }

        select {
            width: 100px;
        }

        #success /*  //from the postdata*/
        {
            text-align: center;
            color: green;
            font-size: 20px;
             }

        #errmsg {
            color: red;
        }


    </style>
</head>
<body cz-shortcut-listen="true">
<div class="center">
    <form method="post" action="{{ url() }}"  enctype="multipart/form-data" id="form">
    
       <!-- @csrf -->
        <h1>Personal Details</h1>
        <span id="errmsg"></span>


        <div>
            <label>First Name</label>
            <input type="text" name="firstname" id="firstname"
                   value="{{(isset($userdata['user_first_name'])? $userdata['user_first_name']:"")}}">
            <span id="error-data-first"></span>

        </div>
        <div>
            <label>Last Name</label>
            <input type="text" name="lastname" id="lastname"
                   value="{{(isset($userdata['user_last_name'])? $userdata['user_last_name']:"")}}">
            <span id="error-data-last"></span>

        </div>
        <div>
            <label>Email</label>
            <input type="text" name="email" id="email"
                   value="{{(isset($userdata['usser_email'])? $userdata['usser_email']:"")}}">
            <span id="error-data-email"></span>


        </div>
        <div>

            <label>Gender</label>
            @if (isset($userdata['user_gender'])&&($userdata['user_gender']==1))
                <input type="radio" name="gender" checked=checked value="1" id="male">male

            @else
                <input type="radio" name="gender" value="1" id="male">male

            @endif
            @if(isset($userdata['user_gender'])&&($userdata['user_gender']==2))
                <input type="radio" name="gender" checked=checked value="2" id="female">female

            @else
                <input type="radio" name="gender" value="2" id="female">female

            @endif


            <span id="error-data-gender"></span>

        </div>
        <div>
            <label>Mobile Number</label>
            <input type="text" name="number" class="numbersonly" id="number" maxlength="10"
                   value="{{(isset($userdata['user_mobile_no'])? $userdata['user_mobile_no']:"")}}">


        </div>
        <div>
            <label>Address1</label>
            <textarea name="address1"
                      id="address1">{{(isset($userdata['user_addr1'])? $userdata['user_addr1']:"")}}</textarea>
            <span id="error-data-address1"></span>

        </div>
        <div>
            <label>Address2</label>
            <textarea name="address2"
                      id="address2">{{(isset($userdata['user_addr2'])? $userdata['user_addr2']:"")}}</textarea>
            <span id="error-data-address2"></span>

        </div>

        <div>
            <label>Country</label>
            <select name="country" id="country">

                @if(count($country))
                    <option value="" selected>Select country</option>
                    @foreach($country as $row)
                        @php($selected="")
                        @php($countryId = isset($userdata['user_ctry_id']) ? $userdata['user_ctry_id']: '')

                        @if($countryId !='')
                            @if($row['ctry_id']==$userdata['user_ctry_id'])
                                @php($selected="selected")
                            @endif
                        @endif
                        <option value="{{$row['ctry_id']}}" {{$selected}}>{{$row['ctry_name']}} </option>

                    @endforeach
                @else
                    <option value="">No options</option>
                @endif
            </select>

            <span id="error-data-country"></span>
        </div>
        <div>
            <label>State</label>
            <select name="state" id="state">
                @if(count($state))
                    <option value="" selected>Select state</option>
                    @foreach($state as $row)
                        @php($selected="")
                        @php($state = isset($userdata['user_stat_id']) ? $userdata['user_stat_id']: '')

                        @if($state !='')
                            @if($row['stat_id']==$userdata['user_stat_id'])
                                @php($selected="selected")
                            @endif
                        @endif
                        <option value="{{$row['stat_id']}}" {{$selected}}>{{$row['stat_name']}} </option>

                    @endforeach
                @else
                    <option value="">No options</option>
                @endif
            </select>

            <span id="error-data-state"></span>
        </div>
        <div>
            <label>City</label>
            <input type="text" name="city" id="city"
                   value="{{(isset($userdata['user_city'])? $userdata['user_city']:"")}}">
            <span id="error-data-city"></span>

        </div>
        <div>
            <label>Pincode</label>
            <input type="text" name="pincode" class="numbersonly" id="pincode" maxlength="6"
                   value="{{(isset($userdata['user_pincode'])? $userdata['user_pincode']:"")}}">
         </div>
        <!-- <div class="btn">
            <input type="submit" name="submit" value="Submit" id="btn">
            </div> -->
            <img src ="{{url('/images/')}}" alt="img">
           
        <div id="container">
            <button type="button" name="submit" id="submitButton">Submit</button>


            <button type="cancel"><a id="button2" href="{{url('/userslist')}}">Cancel</a>
            </button>
        </div>

        <input type="hidden" name="userid" id="userid"
               value="{{( isset ($userdata['user_id'])?$userdata['user_id']:"")}}">
    </form>
</div>
<div id="successdiv"></div>

<script>
    $('body').on('change', '#country', function () {
        var countryId = $("#country").val();
        // alert( countryId );

        $.ajax({
            url: "{{url("countrystate")}}",
            method: "POST",
            data: {
                "_token": "{!! csrf_token() !!}",
                countryId: countryId
            },
             dataType: "JSON",
            success: function (data) {
                if (data.result == false) {

                    $("#state").html("");
                    // alert("Not success");
                    return false;

                } else {
                    $("#state").html(data.states);
                    // alert("success");

                }					// 	url: "ajaxstate.php",
            }
        });//ajax ends

    });//function ends
</script>
<script>
    $(".numbersonly").keypress(function (e) {

        if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
            //display error message
            $("#errmsg").html("numbersonly").show().fadeOut("slow");
            return false;
        }


    });
</script>
<script>

    $('#form').validate({
        errorElement: "div",
        successClass: "inputSuccess",
        rules: {
            firstname:{
                    required: true,
                    maxlength: 50
                 },

            lastname:{
                 required: true,
                 maxlength: 50
                 },

             email: {
                required: true,
                maxlength: 50,
                email: true
                },

            address1:{
                required: true,
                },
            address2:{
                required: true,
                 },

             number:{
                required: true,
                digits: true,
                maxlength: 10
                },
            pincode:{
                required: true,
                digits: true,
                maxlength: 6
                
                },
            gender: {
                required: true,
                },
            city: {
                required: true,
                maxlength: 50
             },
            state: {
                required: true,
            },
            country: {
                required: true,
            },
        },
        messages: {
            firstname: {
                required: "Please enter name",
                maxlength: "Your first name maxlength should be 50 characters long."
            },
            lastname: {
                required: "Please enter name",
                maxlength: "Your last name maxlength should be 50 characters long."
            },
            email: {
                required: "Please enter valid email",
                maxlength: "The email name should less than or equal to 50 characters",
            },
            address1: {
                required: "Please enter address",
            },
            address2: {
                required: "Please enter address",
            },
            number: {
                required: "Please enter contact number",
                digits: "Please enter only numbers",
                maxlength: "The contact number should be 10 digits",
            },
            pincode:{
                required: "Please enter pincode",
                digits: "Please enter only numbers",
                maxlength: "The pincode should be 6 digits",
            },
            gender: {
                required: "Please choose gender",
            },
            city: {
                required: "Please enter city name",
                maxlength: "Your city name maxlength should be 50 characters long."
            },
            state: {
                required: "Please choose state ",
            },
            country: {
                required: "Please choose country",
            },
        },
        errorPlacement: function (error, element) {
            error.appendTo(element.parent());
            error.addClass('invalid-feedback');
            // element.closest('.form-group').append(error);
        },
        highlight: function (element, errorClass, validClass) {
            $(element).addClass('is-invalid');
        },
        unhighlight: function (element, errorClass, validClass) {
            $(element).removeClass('is-invalid');
        }
    });
    // $("form").submit(function () {
    $('body').on('click', '#submitButton', function () {
            if($('#form').valid()) {

            var firstname=$("#firstname").val();
            var lastname=$("#lastname").val();
            var email=$("#email").val();
            var address1=$("#address1").val();
            var address2=$("#address2").val();
            var number=$("#number").val();
            var pincode=$("#pincode").val();
            var gender= $("input[name='gender']:checked").val();
            var city=$("#city").val();
            var state=$("#state").val();
            var country=$("#country").val();
            var image=$("#image").Val();

            $.ajax({
                     url: "{{url("saveform")}}",
                    method: "POST",
                     data: {
                    "_token": "{!! csrf_token() !!}",

                    firstname: firstname,
                    lastname: lastname,
                    email: email,
                    address1: address1,
                    address2: address2,
                    number: number,
                    pincode: pincode,
                    gender: gender,
                    city: city,
                    state: state,
                    country: country,
                    image:image,
                    userid: $("#userid").val()
                },
                dataType: "json",

                success: function (result) {
                    if (result.result == 1) {
                        $("#successdiv").html(result.messege);
                        window.location = "{{url("userslist")}}";
                        // alert(result.status);

                    }
                    if (result.result == 0) {
                        $("#success").html(result.messege);

                    }
                }

                 });//ajax ends
        }


        return false;

    });//submit ends


</script>
</body>
</html>
