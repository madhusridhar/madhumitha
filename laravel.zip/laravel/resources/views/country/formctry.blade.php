@include('layouts.header')
<!DOCTYPE html>
<html><head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
		label
		{
			display: inline-block;
			width: 250px;
		}
	span {
			display:block;
			color:red;
		}	

		div
		{
			margin-top: 10px;
		}
		.center
		{
            display: flex;
			margin: 0 auto;
			justify-content: center;
			align-items: center;
			max-width: 100%;
		}
		/* .btn
		{
			text-align: center;
			margin-top: 50px;
		} */
		#button1{
			padding: 8px 20px;
			display:inline-block;
		}
		#button2{
    	text-decoration: none;
		padding: 8px 20px;
		color: black;
		display:inline-block;
		}
		#container{
    	text-align: center;
		}

		input,select,textarea
		{
		   outline: none;
		}
		.error
		{
			   display:block;
			   margin-top: 10px;
			   color: red;
			   display: none;
			 
		}
        select
		{
			width: 100px;
		}
		#success        /*  //from the postdata*/
		{
			text-align: center;
			color: green;
			font-size: 20px;

		}
		#errmsg{
			color:red;
		}
		#country{
			margin: auto;
			width: 50%;
		}	


	</style>
</head>
<body cz-shortcut-listen="true">
	<div class="center">
		<form method="post">
        <div>
		<label>Country:</label>
			<input type="text" id="country" name="country" value="{{(isset($userdata['ctry_name'])? $userdata['ctry_name']:"")}}">
			 
                  
			<span id="error-data-country"></span>	
</div>

            <div class="btn">
				<input type="submit" name="submit" value="Submit" id="button1">
				<button type="cancel"><a id="button2" href="{{url('/ctrylist')}}">Cancel</a>
        </div>
		<input type="hidden" name="countryid" id="countryid" value="{{( isset($userdata['ctry_id'])?$userdata['ctry_id']:"")}}">
		</form>
	    </div>
	    <div id="successdiv"></div>	
<script>

		$(document).ready(function(){
			$("form").submit(function(){
			var country=$("#country").val();
			// var status=true;
			if(country==""){
			$("#error-data-country").html("please enter country");
				}
			else{
			$("#error-data-country").html("");

			$.ajax({
									url: "{{url("savectry")}}",
									method: "POST",
									data: {  "_token": "{!! csrf_token() !!}",
											country:country,
											ctry_id:$("#countryid").val()
											 },
									dataType: "json",

								success: function(result){
									if (result.status==1){
									$("#successdiv").html(result.messege);
									window.location="{{"ctrylist"}}";
									// alert(result.status);

											}
									if(result.status==0){
									$("#success").html(result.messege);

											}
											
            						}
      
								});//ajax end

			}	
							
				return false;
					});//submit ends
					});//ready ends
</script>
</body>
</html>
				