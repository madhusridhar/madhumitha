@include('layouts.header')
<title>Home</title>
	<style type="text/css">
		*
		{
			margin: 0;
			padding: 0;
		}
		.head
		{
			height: 50px;
			background-color: #3492eb;
		}
		.pd_div
		{
		    background-color: #e7e7e7;
		    height: 50px;
		    display: flex;
		    justify-content: space-between;
		    align-content: center;
		    align-items: center;	   
		}
		.add_user
		{
			 text-decoration: none;
			 background-color: #14c71a;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
		}
		.heading
		{
			margin-left: 20px;
			font-size: 24px;
			font-weight: bold;
		}
		.filter_search
		{
            height: 80px;
            /*background-color: #abdc;*/
            display: flex;
            align-items: center;
            float: right;
            margin-right: 20px;


            /*justify-content: space-between;*/

		}
		.search
		{
			outline: none;
			padding: 5px 8px;
		}
		.search_btn
		{
			padding: 5px 8px;
			cursor: pointer;
		}
		.search_country,.search_state
		{
				padding: 7px 8px;
				cursor: pointer;
				width: 100px;
				outline: none;
		}
		.dlt_btn{
			cursor: pointer;
			text-decoration: none;
			 background-color: red;
			 padding: 8px 20px;
			 /* margin: 0px 20px; */
			 margin-left: 1240px;
			 color: white;
			 border-radius: 20px;
			
			
		}
		.clear
		{
			clear: both;
			display: flex;
			justify-content: center;
		}
		#list 
		{
		  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		  border-collapse: collapse;
		  width: 100%;
        }

        #list td, #list th 
        {
		  border: 1px solid #ddd;
		  padding: 8px;
		  text-align: center;
        }	

        #list th 
        {
          text-align: center;
        }

        #list tr:nth-child(even)
        {
        	background-color: #f2f2f2;
        }

		#list tr:hover 
		{
			background-color: #ddd;
			cursor: pointer;
		}

		#list th 
		{
		  padding-top: 12px;
		  padding-bottom: 12px;
		  text-align: center;
		  background-color: #4CAF50;
		  color: white;
		}
		.pagelist
		{
             text-decoration: none;
             background-color: #182c4d;
             color: white;
             padding: 3px 10px;
		}
		.pagination {
 	 		display: inline-block;
				}

		.pagination a {
 	 	color: black;
  		float: left;
 	 	padding: 8px 16px;
  		text-decoration: none;
		}

		</style>
	<div class="head">
		
	</div>

	<div style="margin:10px;" class="pd_div">
	<p class="heading">State Details</p>
    <a  class="add_user" href="{{url('/stateform')}}">Add State</a>
		</div>
		<div style="margin:10px;">
		</div>

	<div class="clear">
</div>
<div id="target-content"><table id="list">
<tr>


	    <thead>
		 <tr>
			<th>Country</th>
            <th>State</th>
            <th>Edit</th>
			<th>Delete</th>
				
		</tr>
			
		</thead>	
		
	<tbody id="tabledata">
    @foreach($data as $tr)
		
		     <tr>
             <td>{{ $tr['ctry_name'] }}</td>
		   	 <td>{{ $tr['stat_name'] }}</td> 
                <td><a href="{{ url('editstate',$tr['stat_id'])}}">edit</a></td>
		   		<td><a href="#" class="delete" onclick="deletefun({{ $tr['stat_id']}})">delete</a></td>
				   
            </tr> 
		   @endforeach
		   </div>

 </tbody>
 </table>
 <script type="text/javascript">
                    $(document).ready(function() {
  		  			$('#list').DataTable();
					} );
 

</script>
<script>
function deletefun(statid)
		{
			var statid= statid;
				// alert(ctryid);
					if(confirm("Are  you want to delete")){

						$.ajax({ 
							url: "{{url("deletestate")}}"+ "/" + statid,
							method: "GET",
						// data: {id:id},
							dataType: "json",
							success: function(result){
							if(result.result==true){
							alert("Record deleted successfully");
							window.location="{{url("statelist")}}";
							}if(result.result==false){
								alert("Record not deleted successfully");
								
							}
							
							}

					});

		
			}
	}
		
						
        </script>

</body>
</html>