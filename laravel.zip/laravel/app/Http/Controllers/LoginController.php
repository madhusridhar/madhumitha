<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Auth;
use DB;
use Illuminate\Support\Facades\Session;
class LoginController extends Controller
{
    // echo '<pre>';print_r('hii');exit; 
    public function logout(Request $request) {
        // echo '<pre>';print_r($request);exit; 
        Auth::logout();
        return redirect('/login');
      }
      //already logged user deleted not allowed to login again
    public function authlogin(Request $request){
        // echo '<pre>';print_r($request);exit; 
        
        $getUser = User::where([["email", '=', $request->input('email')], ['deleted_flg', '=', 0]])->first();
          if (!$getUser) {
            $message = Session::flash('message', "Sorry! Details are not found");
            return view('auth.login')->with('message', 'Sorry! Details are not found.');
          }

     $credentials = array(
        "email" => $request->input('email'),
        "password" => $request->input("password")
     );
        if (Auth::attempt($credentials, $request->input('remember'))) {

        $userId = Auth::user()->id;
        $user = new User();
        return Redirect::to('home');
    } else {
        $message = Session::flash('error', "You can't able to delete this brand");
        return redirect('/')->with('message', 'error');
        
           }
    }
}