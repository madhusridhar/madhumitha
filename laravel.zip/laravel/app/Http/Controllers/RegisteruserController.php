<?php

namespace App\Http\Controllers;
use App\User;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use DB;     
class RegisteruserController extends Controller
{
    public  function index(){
         $data=user::where('deleted_flg', '=', 0)->select()->get();
        return view('register\indexregister')->with('data',$data);
        
    } 
    public function form(){
        $users = User::select()->get();
        $userdata="";
        return view('register\formregister')
        ->with('user', $users)->with('userdata',$userdata);

    }

    public function delete($id){
       
            $users = User::where('deleted_flg', '=', 0)->find($id);
            if (!$users) {
            die(json_encode(array('result' => false, 'message' => "Unable to delete this place.")));
            
        }else{
               
            $userupdate = array();
           
            $userupdate['id'] = $id;
             $userupdate['deleted_flg']= 1;
            //  print_r($userupdate);exit;
             $users = User::where('id','=', $id)->update($userupdate);
             die(json_encode(array('result' => false, 'message' => "Deleted successfully.")));
             Auth::logout();
             return redirect('/login');
       
        }
    }

    public function store(Request $request){
        $input = Input::all();
                                        //left side DB val
        if (!empty($input['id'])){      //right side ajax val
            // $country->ctry_id = $input['ctry_id'];
           
            $user =array();
            $user['id'] = $input['id'];
            $user['name'] = $input['name'];
            $user['email'] = $input['email'];

            $users = User::where('id','=',$input['id'])->update($user);
            
            
           
    }else{

             $user =array();
            $user['id'] = false;
            $user['name'] = $input['name'];
            $user['email'] = $input['email'];

        $users=User::insertGetId($user);

    }

    
        die(json_encode(array('result' => true, 'message' => 'datas stored successfully')));
    
 }

 public function save(){
    echo '<pre>';print_r('hi');exit;
   
}
    public function edit($id){
        $users=user::where('id', '=', $id)
        ->select('users.*')
        ->first();
      
        return view('register\formregister')
        ->with('userdata',$users);
    }

}

