<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\PersonaldetailModel;
use App\CountryModel;
use Illuminate\Support\Facades\Input;
use DB; 

class CountryController extends Controller
{
    public  function indexctry(){
        $data=CountryModel::
        select('tbl_country.*')
        ->get();
        return view('country\indexctry')->with('data',$data);
 
 }
    public function formctry(){
        $country=CountryModel::select()->get();
        $userdata="";
        return view('country\formctry')
        ->with('country', $country)->with('userdata',$userdata);

 }
    public function storectry(Request $request){
        $input = Input::all();
        // $country = new CountryModel();
        if (!empty($input['ctry_id'])){      //right side ajax val
            // $country->ctry_id = $input['ctry_id'];

            $country =array();
            $country['ctry_id'] = $input['ctry_id'];
            $country['ctry_name'] = $input['country'];
            $countrymodel = CountryModel::where('ctry_id','=',$input['ctry_id'])->update($country);
            // print_r($countrymodel);exit;
            
           
    }else{

             $country =array();
            $country['ctry_id'] = false;
            $country['ctry_name'] = $input['country'];

        $countrymodel=CountryModel::insertGetId($country);

    }

    
        die(json_encode(array('result' => true, 'message' => 'datas stored successfully')));
    
 }

 public function save(){
    echo '<pre>';print_r('hi');exit;
}
public function editctry($ctryid){
    $country = CountryModel::where('ctry_id', '=', $ctryid)
    ->select('tbl_country.*')
     ->first();
    //  echo '<pre>';print_r($country);exit;
    // $country=CountryModel::select()->get();
    return view('country/formctry')
    ->with('userdata', $country);
}

public function deletectry($ctryid){
    $userdetail = PersonaldetailModel::where('user_ctry_id', '=',$ctryid )->first();
    $state = StateModel::where('stat_ctry_id','=',$ctryid)->first();
    // print_r($state);exit;
  if ($userdetail!= "" ||$state!= ""){
        die(json_encode(array('result' => false, 'message' => "Cannot delete this field.")));
    } else {
        $country = CountryModel::where('ctry_id', '=', $ctryid)->first();

    }

    

if (!$country) {

    die(json_encode(array('result'=>false,'message' => "cannot delete this field")));
}else{

    $country = CountryModel::where('ctry_id','=',$ctryid)->delete();
    die(json_encode(array('result'=> true,'messege'=>"Deleted successfully")));
    }
}   

 }
