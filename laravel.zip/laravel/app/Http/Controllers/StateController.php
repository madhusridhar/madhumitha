<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\StateModel;
use App\CountryModel;
use App\PersonaldetailModel;
use Illuminate\Support\Facades\Input;
use DB; 

class StateController extends Controller
{
    public  function indexstate(){
        $data=StateModel::
        join('tbl_country', 'tbl_country.ctry_id', '=', 'tbl_state.stat_ctry_id')
        ->select('tbl_country.ctry_name','tbl_state.*')
        ->get();
        return view('state\indexstate')->with('data',$data);
 
 }
 public function formstate(){
// 
    $country=CountryModel::select()->get();    
    $userdata="";

        return view('state\formstate')
         ->with('country', $country)->with('userdata',$userdata);
} 
public function storestate(Request $request){
    // echo '<pre>';print_r($request);exit;
         $input = Input::all();
        
         if(!empty($input['stat_id'])){
        
            $state=array(); 
            $state['stat_id']=$input['stat_id'];
            $state['stat_name']=$input['state'];
            $state['stat_ctry_id']=$input['ctry_id'];
            $statemodel = StateModel::where('stat_id','=',$input['stat_id'])->update($state);
           
            // print_r($state);exit;
            

        }else{
            $state=array(); 
            $state['stat_id']=false;
            $state['stat_name']=$input['state'];
            $state['stat_ctry_id']=$input['ctry_id'];

            $statemodel=StateModel::insertGetId($state);
 }
        
     die(json_encode(array('result' => true, 'message' => 'datas stored successfully')));

}
           
 public function save(){
                 echo '<pre>';print_r('hi');exit;
    }
    public function editstate($statid){
        $state = StateModel::where('stat_id', '=', $statid)
       ->select('tbl_state.*')
        ->first();
        $country=CountryModel::select()->get();

        return view('state/formstate')
        ->with('userdata', $state)->with('country', $country);
}
public function deletestate($statid){

    $stat= PersonaldetailModel::where('user_stat_id', '=',$statid )->first();


    if ( $stat!= "") {
        die(json_encode(array('result' => false, 'message' => "Cannot delete this field.")));
    } else {
        $state = StateModel::where('stat_id', '=', $statid)->first();

    }
if (!$state) {

    die(json_encode(array('result'=>false,'message' => "cannot delete this field")));
}else{

    $state =StateModel::where('stat_id','=',$statid)->delete();
    die(json_encode(array('result'=> true,'messege'=>"Deleted successfully")));
    }
}   

}
    

