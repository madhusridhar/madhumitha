<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\PersonaldetailModel;
use App\CountryModel;
use App\StateModel;
use Illuminate\Support\Facades\Input;
use DB; 


class FormController extends Controller
{
    public  function index(){
        $data=PersonaldetailModel::
        join('tbl_state', 'tbl_state.stat_id', '=', 'tbl_personal_detail.user_stat_id')
       ->join('tbl_country', 'tbl_country.ctry_id', '=', 'tbl_personal_detail.user_ctry_id')
       -> select('tbl_personal_detail.*','tbl_state.stat_name','tbl_country.ctry_name')

       ->orderBy('user_id')->get();
        // echo '<pre>';print_r($data);exit;
        return view('user\index')->with('data',$data);

    }
    public function form(){
        $country=CountryModel::select()->get();
        // echo '<pre>';print_r($demo);

        $state=StateModel::select()->get();
        // echo '<pre>';print_r($demo);
        $userdata="";

        return view('user\form')
       ->with('country', $country)->with('state',$state)->with('userdata',$userdata);
      
    }
    public function store(Request $request){
           
        // echo '<pre>';print_r($request);exit;
            $input = Input::all();
            $PersonaldetailModel = new PersonaldetailModel();//if condi for update
            if (!empty($input['user_id'])){
                 // $PersonaldetailModel = PersonaldetailModel::where('user_id', '=', $input['user_id'])
                // ->select('tbl_personal_detail.*')
                // ->first();
                 $PersonaldetailModel->user_id = $input['user_id'];

            }else{

                // $PersonaldetailModel = new PersonaldetailModel();
                $PersonaldetailModel->user_id = false;

            }
            //  echo '<pre>';print_r($input);exit;
            
            
            // echo '<pre>';print_r($PersonaldetailModel);exit;
        if (!empty($input)) {
            
            $PersonaldetailModel->user_first_name= $input['firstname'];
            $PersonaldetailModel->user_last_name= $input['lastname'];
            $PersonaldetailModel->usser_email= $input['email'];
            $PersonaldetailModel->user_gender= $input['gender'];
            $PersonaldetailModel->user_mobile_no= $input['number'];
            $PersonaldetailModel->user_addr1= $input['address1'];
            $PersonaldetailModel->user_addr2= $input['address2'];
            $PersonaldetailModel->user_ctry_id= $input['country'];
            $PersonaldetailModel->user_stat_id= $input['state'];
            $PersonaldetailModel->user_city= $input['city'];
            $PersonaldetailModel->user_pincode= $input['pincode'];


        };
       
       $PersonaldetailModel->save();
    

        die(json_encode(array('result' => true, 'message' => 'datas stored successfully')));
    }
    public function save(){
                 echo '<pre>';print_r('hi');exit;
    }


    public function edit($id){
        $PersonaldetailModel = PersonaldetailModel::where('user_id', '=', $id)
       ->select('tbl_personal_detail.*')
        ->first();
        //  echo '<pre>';print_r($PersonaldetailModel);exit;

        $country=CountryModel::select()->get();
        $state=StateModel::select()->get();
        return view('user\form')
        ->with('userdata',$PersonaldetailModel)->with('country', $country)->with('state',$state);
    
    }

    public function delete($id){
    
        $PersonaldetailModel = PersonaldetailModel::where('user_id', '=', $id)->first();

    if (!$PersonaldetailModel) {

        die(json_encode(array('result'=>false,'message' => "cannot delete this field")));
    }else{

        $PersonaldetailModel = PersonaldetailModel:: where('user_id','=',$id)->delete();
        die(json_encode(array('result'=> true,'messege'=>"Deleted successfully")));
        }
    }   

    //state country dropdown
public function getStates(\Illuminate\Http\Request $request)
    {

        // get category value by input
        $input = Input::all();


        if (!$input) {
            die(json_encode(array('result' => "false", 'message' => "Please select country")));
        }

        $countryId = $input['countryId'];


        $getState = StateModel::where('stat_ctry_id', '=',  $countryId )->select('stat_name','stat_id')->get();


        //          assigning the sub category as html
        if ($getState->isEmpty()) {
            die(json_encode(array("result" => "false", 'message' => "This country doesn't have any state.Please choose another country")));
        }

         $states = "Please Select state";
        $states = '<option class="slct" value="' . 0 . '">' . "Please Select state" . '</option>';
        foreach ($getState as $getStateVal) {

            $states .= '<option value="' . $getStateVal->stat_id . '">' . $getStateVal->stat_name . '</option>';
        }

        die(json_encode(array("result" => "true", 'message' => "Please Select State", 'states' => $states )));

    }
    //bulk delete
    public function deleteAll(Request $request)
    {
        $id = $request->id;
       DB::table("tbl_personal_detail")->whereIn('user_id',explode(",",$id))->delete();
       $PersonaldetailModel = PersonaldetailModel::whereIn('user_id',explode(",",$id))->delete();

             if (!$PersonaldetailModel) {
                die(json(['success'=>" Not deleted successfully."]));
             }else{

         $PersonaldetailModel = PersonaldetailModel:: where('user_id','=',$id)->delete();
            die(json(['success'=>"Deleted successfully."]));
        }  
    

    }

}
