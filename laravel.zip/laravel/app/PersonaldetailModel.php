<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PersonaldetailModel extends Model
{
    protected $table= 'tbl_personal_detail';
    public $timestamps = false;
}
