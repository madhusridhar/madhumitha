<?php
				include("../connection.php");
?>
<!DOCTYPE html>
<!-- saved from url=(0022)http://localhost/task/ -->
<html><head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<!-- <link rel="stylesheet" id="font-awesome-style-css" href="./list_files/bootstrap3.min.css" type="text/css" media="all"> -->
	<!-- <script type="text/javascript" charset="utf8" src="./list_files/jquery-1.8.2.min.js.download"></script> -->

	<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
	<title>Home</title>
	<style type="text/css">
		*
		{
			margin: 0;
			padding: 0;
		}
		.head
		{
			height: 50px;
			background-color: #3492eb;
		}
		.pd_div
		{
		    background-color: #e7e7e7;
		    height: 50px;
		    display: flex;
		    justify-content: space-between;
		    align-content: center;
		    align-items: center;	   
		}
		.add_user
		{
			 text-decoration: none;
			 background-color: #14c71a;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
		}
		.heading
		{
			margin-left: 20px;
			font-size: 24px;
			font-weight: bold;
		}
		.filter_search
		{
            height: 80px;
            /*background-color: #abdc;*/
            display: flex;
            align-items: center;
            float: right;
            margin-right: 20px;


            /*justify-content: space-between;*/

		}
		.search
		{
			outline: none;
			padding: 5px 8px;
		}
		.search_btn
		{
			padding: 5px 8px;
			cursor: pointer;
		}
		.search_country,.search_state
		{
				padding: 7px 8px;
				cursor: pointer;
				width: 100px;
				outline: none;
		}
		.dlt_btn{
			cursor: pointer;
			text-decoration: none;
			 background-color: red;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
			
		}
		.clear
		{
			clear: both;
			display: flex;
			justify-content: center;
		}
		#list 
		{
		  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		  border-collapse: collapse;
		  width: 100%;
        }

        #list td, #list th 
        {
		  border: 1px solid #ddd;
		  padding: 8px;
		  text-align: center;
        }	

        #list th 
        {
          text-align: center;
        }

        #list tr:nth-child(even)
        {
        	background-color: #f2f2f2;
        }

		#list tr:hover 
		{
			background-color: #ddd;
			cursor: pointer;
		}

		#list th 
		{
		  padding-top: 12px;
		  padding-bottom: 12px;
		  text-align: center;
		  background-color: #4CAF50;
		  color: white;
		}
		.pagelist
		{
             text-decoration: none;
             background-color: #182c4d;
             color: white;
             padding: 3px 10px;
		}
	
	</style>
</head>
<body cz-shortcut-listen="true">
	<div class="head">
		
	</div>

	<div class="pd_div">
		<p class="heading">country state Details</p>
		<a class="add_user" href="addctrystat.php">Add CountryState</a>
	</div>

	<div class="filter_search">
		<div class="search_right">
			<select class="search_country" id="search_input_country" name="">
				<option value="">Select</option>
			<?php
				// include("connection.php");

			$sql = "SELECT ctry_id, ctry_name  FROM tbl_country";
			$result = $conn->query($sql);
				
			if ($result->num_rows > 0) {
				  // output data of each row
				 while($row = $result->fetch_assoc()) {
					 if($userdata['user_ctry_id']==$row['ctry_id']){
					echo '<option selected="selected" value="'.$row["ctry_id"].'">'.$row["ctry_name"].'</option>';
				}
				else{
					echo '<option value="'.$row["ctry_id"].'">'.$row["ctry_name"].' </option>';

				}
			}
		}  
			?>
			
	
</select>

			<!-- <select name="state" id="state" class="search_state"> -->
			       <!-- <option value="">Select</option> -->
		<?php
			//  include("connection.php");

		// 	$sql = "SELECT stat_id, stat_name  FROM tbl_state";
		// 	$result = $conn->query($sql);
				
		// 	if ($result->num_rows > 0) {
		// 		  // output data of each row
		// 		 while($row = $result->fetch_assoc()) {
		// 			 if($userdata['user_stat_id']==$row['stat_id']){
		// 			echo '<option selected="selected" value="'.$row["stat_id"].'">'.$row["stat_name"].'</option>';
		// 		}
		// 		else{
		// 			echo '<option value="'.$row["stat_id"].'">'.$row["stat_name"].' </option>';

		// 		}
		// 	}
		// } 
			?>


		<!-- </select> -->
			<input type="text" class="search" id="search_input" name="" placeholder="Search">
			<button class="search_btn" id="search_btn" name="search">Search</button>
			<a class="dlt_btn" id="blkdelete">Delete</a>
			
		

	     </div>
	</div>

<div class="clear">
	 </div>


<?php
	// include("connection.php");

	$sql="SELECT * from tbl_state 
			inner join tbl_country on stat_ctry_id= ctry_id 
			  order by stat_id ";
	$result = $conn->query($sql);
	$row_count = mysqli_num_rows($result);
	// echo $row_count;die;

?>

<div id="target-content">

<table id="list">

	    <thead>
            <tr>
				<th><input type="checkbox" class= "checked_all"></th>
				
				<th>Country</th>
				<th>State</th>
				<th>Edit</th>
				<th>Delete</th>
			
        </tr>
		
		
	</thead>	
	   <tbody id="tabledata"> 
	   <?php
	   while($tr = $result->fetch_assoc()){
		?>
		     <tr>
		    	 <td><input type="checkbox" class="checkbox"  value="<?php echo $tr['stat_id']?>"></td> 
				<td><?php echo $tr['ctry_name'] ?></td>
				<td><?php echo $tr['stat_name'] ?></td>
				<td><a href="addctrystat.php?id=<?php echo $tr['stat_id'] ?>">Edit </a></td>
				<td><a href="#" class="delete" onclick="deletefun(<?php echo $tr['stat_id']?>)">delete</a></td>
				   

		    </tr> 
		   <?php }
		   ?>

 </tbody></table>
	

</div>
	
<script type="text/javascript">
		$(document).ready(function() {

						$('.checked_all').on('change', function() {     
               			 $('.checkbox').prop('checked', $(this).prop("checked"));              
        					});
        //deselect "checked all", if one of the listed checkbox product is unchecked amd select "checked all" if all of the listed checkbox product is checked
        		$('.checkbox').change(function(){
					 //".checkbox" change 
            		if($('.checkbox:checked').length == $('.checkbox').length){
                  	 $('.checked_all').prop('checked',true);
           		 }else{
                  	 $('.checked_all').prop('checked',false);
            }
        });



			$('#blkdelete').click(function(){
				var id = [];
				$(':checkbox:checked').each(function(i){
 				id[i] = $(this).val();
			 }); 
			 //alert(id); return false;
 			if(id.length === 0)
		 	{
 			alert("Please Select Checkbox");
			 return false;
 			}

 		if(confirm("Are you sure to delete?"))
 			{
 				
 	
 		
 		$.ajax({
 							url:"deletectrystat.php",
 							method: "POST",
 							data:{id:id},
 							success:function()
							{
								window.location="indexctrystat.php";
 							
 							}
 				});//ajax ends
							 
			 }//if ends
 			});//click ends



	$( "#search_input_country" ).change(function() {
		var country=$("#search_input_country").val();

	
		
				 
	});

	$( "#search_btn" ).click(function() {
		
						var country=$("#search_input_country").val();
						// // alert( country );
						// var state=	$("#state").val();
						var input=	$("#search_input").val();
						$.ajax({ 
									url: "slist.php",
									method: "POST",
									data: { 
											country: country,
											// state:state,
											input:input
											},
									dataType: "html",
									success: function(result){
									$("#tabledata").html(result);
            						}
      
								});//ajax ends


});// search click ends
	
	// 				// alert("test");
	});  //ready function end

function deletefun(id)
	{
		var id=id;
				// alert(id);
				if(confirm("Are  you want to delete")){

					$.ajax({ 
						url: "deletectrystat.php",
						method: "POST",
						data: {id:id},
						dataType: "html",
						success: function(result){
							window.location="indexctrystat.php";
						// alert("Record deleted successfully");
						}

					});//ajax end

		
			}
	}
						
        </script>

</body>
</html>