<?php
include("../connection.php");
$country=$_POST['country'];
// $state=$_POST['state'];
$input=$_POST['input'];

        $sql="SELECT * from tbl_state 
        inner join tbl_country on stat_ctry_id= ctry_id  WHERE 1 = 1  ";
               
               if($country!=""){
                $sql .= " AND ctry_id =".$country ;
            }
              
                // inner join tbl_state on user_stat_id=stat_id  
      
        
        // if($state!=""){
        //     $sql .= " AND stat_id =".$state ;
        // }
        if($input!=""){
            $sql .= " AND (
                            ctry_name LIKE '" .$input ."%' ||
                            stat_name LIKE '" .$input ."%' 
                            
                            ) ";


            
        }
       
        $result = $conn->query($sql);
        $row_count = mysqli_num_rows($result);
        echo $row_count;
if($row_count==0){?>
<tr>
<td colspan="5">No data available
                    </td>
</tr>
<?php

}else{


         while($tr = $result->fetch_assoc()){
                    ?>
                        <tr>
                           <td><input type="checkbox" ></td>
                           
                              <td><?php echo $tr['ctry_name'] ?></td>
                              <td><?php echo $tr['stat_name'] ?></td>
                             
                              <td><a href="addctrystat.php?id=<?php echo $tr['stat_id'] ?>">Edit </a></td>
                              <td><a class="delete" href="delete.php?id=<?php echo $tr['stat_id'] ?>">delete</a></td>
                              
                       </tr> 
                      <?php }
        }
                   ?>

              
    