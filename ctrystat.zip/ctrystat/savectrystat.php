<?php
include("../connection.php");

// if(isset($_POST['submit'])){


$country=$_POST['country'];
$state=$_POST['state'];
$statid=$_POST['statid'];

// die;

if( $statid == 0 ) {

    $sql="INSERT INTO tbl_state(stat_ctry_id,stat_name)VALUES('$country','$state')";
    // echo $sql;die;
    $conn->query($sql);
    $last_id = $conn->insert_id;
    if($last_id ){
        echo json_encode(array("status"=>1,"message"=>" Data  inserted Successfully"));
    } else {
        echo json_encode(array("status"=>0,"message"=>"Data  not inserted successfully"));
    }


} else {

    $sql="UPDATE tbl_state
    set 
    stat_ctry_id='$country',
    stat_name='$state'
    
     WHERE stat_id='$statid'";
//    echo $sql;die;
    $update= $conn->query($sql);
    if($update){
        echo json_encode(array("status"=>1,"message"=>" Data  updated Successfully"));
    }else{
        echo json_encode(array("status"=>0,"message"=>"Data  not updated successfully"));
    }
    
    }
//     ?>

