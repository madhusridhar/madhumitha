<?php
 include("../connection.php");
 
?>
<!DOCTYPE html>
<html><head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Country State Details</title>
	
	
	<style type="text/css">
		label
		{
			display: inline-block;
			width: 250px;
		}
	span {
			display:block;
			color:red;
		}	

		div
		{
			margin-top: 10px;
		}
		.center
		{
            display: flex;
			margin: 0 auto;
			justify-content: center;
			align-items: center;
			max-width: 100%;
		}
		.btn
		{
			text-align: center;
			margin-top: 10px;
		}
		input,select,textarea
		{
		   outline: none;
		}
		.error
		{
			   display:block;
			   margin-top: 10px;
			   color: red;
			   display: none;
			 
		}
        select
		{
			width: 100px;
		}
		#success        /*  //from the postdata*/
		{
			text-align: center;
			color: green;
			font-size: 20px;

		}


	</style>
</head>
<body cz-shortcut-listen="true">
	<div class="center">
		<form method="post">
			<h1>Country state details</h1>
	<?php
		$id=isset($_GET['id'])? $_GET['id']:"0";
		// echo $id;
		// if($id){
			$query="SELECT * FROM tbl_state where stat_id=$id";
			$result = $conn->query($query);
			$userdata = $result->fetch_assoc();
			
		
		// }
		?>


				
				


<div>
		<label>Country</label>
			<select name="country" id="country">
			 <option value="">Select</option>
			 <?php
			$sql = "SELECT ctry_id, ctry_name  FROM tbl_country";
			$result = $conn->query($sql);
				
			if ($result->num_rows > 0) {
				  // output data of each row
				 while($row = $result->fetch_assoc()) {
					 if($userdata['stat_ctry_id']==$row['ctry_id']){
					echo '<option selected="selected" value="'.$row["ctry_id"].'">'.$row["ctry_name"].'</option>';
				}
				else{
					echo '<option value="'.$row["ctry_id"].'">'.$row["ctry_name"].' </option>';

				}
			}
		}  
			?>
			</select>	
			<span id="error-data-country"></span>	
</div>	
<div>
			<label>State</label>
			
			<input type="text" name="addctrystat" id="state" value="<?php echo(isset($userdata['stat_name'])? $userdata['stat_name']:"");?>">
			<!-- <?php
		// 	$sql = "SELECT stat_id, stat_name  FROM tbl_state";
		// 	$result = $conn->query($sql);
				
		// 	if ($result->num_rows > 0) {
		// 		  // output data of each row
		// 		 while($row = $result->fetch_assoc()) {
		// 			 if($userdata['user_stat_id']==$row['stat_id']){
		// 			echo '<option selected="selected" value="'.$row["stat_id"].'">'.$row["stat_name"].'</option>';
		// 		}
		// 		else{
		// 			echo '<option value="'.$row["stat_id"].'">'.$row["stat_name"].' </option>';

		// 		}
		// 	}
		// } 
			?> -->


		
			<span id="error-data-state"></span>	
</div>	

				
				
</div>
			<div class="btn">
				<input type="submit" name="submit" value="Submit" id="btn">
			</div>
			<input type="hidden" name="statid" id="stat_id" value="<?php echo $id;?>">
		</form>
	</div>
	<div id="successdiv"></div>
	
	<script>
		$(document).ready(function(){
			



                        $("form").submit(function(){

					
                    var state=$("#state").val();
                    var country=$("#country").val();
					var status=true;
					

					
					if(state==""){
						$("#error-data-state").html("please enter state");
						status=false;
                                }
						else{
								$("#error-data-state").html("");

								}

					if(country==""){
						$("#error-data-country").html("please enter country");
						status=false;
                                }
					else{
						$("#error-data-country").html("");

								}
					if(status)	{			
			  		 $.ajax({
									url: "savectrystat.php",
									method: "POST",
									data: { 
											state:state,
											country:country,
											statid:$("#stat_id").val()
											 },
									dataType: "json",

								success: function(result){
									if (result.status==1){
									$("#successdiv").html(result.messege);
									window.location="indexctrystat.php";
									// alert(result.status);

											}
									if(result.status==0){
									$("#success").html(result.messege);

											}
											
            						}
      
								});//ajax end
							
					}//if ends
					return false;
						});//submit end
						
                });//ready end


</script>
</body>
</html>