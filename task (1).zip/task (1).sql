-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2020 at 08:32 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_country`
--

CREATE TABLE `tbl_country` (
  `ctry_id` int(11) NOT NULL,
  `ctry_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_country`
--

INSERT INTO `tbl_country` (`ctry_id`, `ctry_name`) VALUES
(2, 'India'),
(3, 'German'),
(5, 'England'),
(8, 'London'),
(16, 'japan'),
(17, 'chinaaa'),
(20, 'francis'),
(21, 'USA');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_personal_detail`
--

CREATE TABLE `tbl_personal_detail` (
  `user_id` int(11) NOT NULL,
  `user_first_name` varchar(100) DEFAULT NULL,
  `user_last_name` varchar(100) DEFAULT NULL,
  `usser_email` varchar(100) DEFAULT NULL,
  `user_gender` tinyint(4) DEFAULT NULL,
  `user_mobile_no` bigint(20) DEFAULT NULL,
  `user_addr1` varchar(255) DEFAULT NULL,
  `user_addr2` varchar(255) DEFAULT NULL,
  `user_ctry_id` int(11) DEFAULT NULL,
  `user_stat_id` tinyint(4) DEFAULT NULL,
  `user_city` varchar(100) DEFAULT NULL,
  `user_pincode` mediumint(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_personal_detail`
--

INSERT INTO `tbl_personal_detail` (`user_id`, `user_first_name`, `user_last_name`, `usser_email`, `user_gender`, `user_mobile_no`, `user_addr1`, `user_addr2`, `user_ctry_id`, `user_stat_id`, `user_city`, `user_pincode`) VALUES
(30, 'Adam', 'V', 'coolsaran19@gmail.com', 1, 7689757878, 'hh nagar', '56k', 1, 1, 'canada', 888777),
(38, 'madhu', 'mitha', 'madhu@gmail.com', 2, 7689757878, 'gg nagar', '27 j', 2, 5, 'tiruvannamalai', 606601),
(40, 'yuva', 'G', 'yuvv@gmail.com', 2, 7689757878, 'gjhghbj', '55', 1, 2, 'bkjbjkb', 657867),
(41, 'moni', 's', 'moni@gmail.com', 2, 7689757878, 'hfjkhjk', '77', 2, 5, 'chennai', 606601),
(42, 'renu', 'p', 'renu@gmail.com', 2, 6346777355, 'jkhjkhjk', 'bkbjkb', 1, 3, 'jfjjjj', 606601),
(43, 'atchu', 'j', 'atchu@gmail.com', 2, 6564787656, 'bhkjkhj', 'njhjhfj', 2, 6, 'bangalore', 676724),
(44, 'divya', 'c', 'divi@gmail.com', 2, 7689757878, 'bhjghk', '66u', 2, 6, 'jfjjjj', 606601),
(45, 'keerthu', 'B', 'keerth@gmail.com', 2, 7689757878, 'hjkhjhj', '67', 1, 1, 'kjjjij', 888777),
(46, 'sanju', 'v', 'sanju@gmail.com', 2, 6346777355, 'jhghg', 'ytyuty5', 3, 11, 'jjh', 756687),
(47, 'pooji', 's', 'pooj@gmail.com', 2, 6564787656, 'hghgh', '667', 2, 6, 'hhkk', 756687),
(48, 'nawaz', 'y', 'naw@gmail.com', 1, 7689757878, 'hiihui', 'uiyyui', 2, 5, 'chennai', 888777),
(49, 'keerthi', 's', 'keerthi@gmail.com', 1, 6346777355, 'ghgghg', 'ytytyt', 3, 10, 'jfjjjj', 676724),
(50, 'harish', 'p', 'hari@gmail.com', 1, 7689757878, 'bhghjk', 'bjkfhjh', 1, 1, 'hhkhjk', 756687),
(51, 'priya', 'dharshni', 'priya@gmail.com', 2, 6346777355, 'bhgkhjkh', 'njhfjll', 3, 9, 'kjjjij', 756687),
(52, 'subi', 'D', 'subi@gmail.com', 2, 7689757878, 'bhkkhu', 'hfkfhjkh', 2, 6, 'jkhjkhj', 756687),
(53, 'deepika', 'D', 'deeps@gmail.com', 2, 7878768755, 'gghgh', 'jshh', 1, 4, 'hfjkhjfhj', 676724),
(54, 'prathiksha', 'B', 'prathi@gmail.com', 2, 7878768755, 'gfhghk', 'ghwhr', 1, 2, 'ojojoj', 676724),
(55, 'gayathri', 'v', 'gayu@gmail.com', 2, 7878768755, 'hghkkj', 'hhfjkh', 2, 6, 'vvbnbn', 888777),
(56, 'virat', 'kohli', 'virat@gmail.com', 1, 6564787656, 'vjgvhkjkd', 'bjhdjl', 2, 7, 'bangalore', 756687),
(57, 'MSD', 'DHONI', 'dhoni7@gmail.com', 1, 7689757878, 'bkbhjkashdj', 'hwehwejh', 2, 7, 'chennai', 888777),
(58, 'losliya', 'k', 'los@gmail.com', 2, 6346777355, 'jhgjhgh', 'ggww', 2, 8, 'ojojoj', 888777),
(59, 'Rio', 'raj', 'rio@gmail.com', 1, 7689757878, 'hihuihui', 'behigr', 3, 10, 'rert', 888777),
(60, 'gabi', 'B', 'gabi@gmail.com', 2, 7878768755, 'hhhkgjkhg', 'rrg', 1, 1, 'kjjjij', 606601),
(61, 'sanam', 'shetty', 'sanam@gmail.com', 2, 6346777355, 'hghigui', 'fhguhu', 3, 9, 'jfjjjj', 606601);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_state`
--

CREATE TABLE `tbl_state` (
  `stat_id` int(11) NOT NULL,
  `stat_ctry_id` int(11) DEFAULT NULL,
  `stat_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_state`
--

INSERT INTO `tbl_state` (`stat_id`, `stat_ctry_id`, `stat_name`) VALUES
(1, 1, 'California'),
(2, 1, 'Washington'),
(3, 1, 'Texas'),
(4, 1, 'Florida'),
(5, 2, 'Tamilnadu'),
(6, 2, ' Kerala'),
(7, 2, 'Delhi'),
(8, 2, 'Kolkata'),
(9, 3, 'Berlin'),
(10, 3, 'Hamburg'),
(11, 3, 'Saxony'),
(12, NULL, 'andhra');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Madhumitha', 'madhu11@gmail.com', NULL, '$2y$10$UdJj8SeXwTXvp9fVXYKuiOIfhuEz7HFfr/RATEYQBuy52CbiFgI4S', 'zq5pFPoGPLYp7On9GBvLS3xNYUopv8QVmckSmgOnshkuAGDipovsaM36Z1t3', '2020-11-28 06:57:37', '2020-11-28 06:57:37'),
(2, 'pavithra', 'pavi@gmail.com', NULL, '$2y$10$IC4SGG3fyJR15J7LKsQzpOc6jdJqKwGFmYqVYLE/SUQaxaCuC1CaC', NULL, '2020-11-30 00:16:36', '2020-11-30 00:16:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `tbl_country`
--
ALTER TABLE `tbl_country`
  ADD PRIMARY KEY (`ctry_id`);

--
-- Indexes for table `tbl_personal_detail`
--
ALTER TABLE `tbl_personal_detail`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `tbl_state`
--
ALTER TABLE `tbl_state`
  ADD PRIMARY KEY (`stat_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_country`
--
ALTER TABLE `tbl_country`
  MODIFY `ctry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbl_personal_detail`
--
ALTER TABLE `tbl_personal_detail`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `tbl_state`
--
ALTER TABLE `tbl_state`
  MODIFY `stat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
