<?php
 include("connection.php");
 
?>
<!DOCTYPE html>
<html><head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Add Details</title>
	
	
	<style type="text/css">
		label
		{
			display: inline-block;
			width: 250px;
		}
	span {
			display:block;
			color:red;
		}	

		div
		{
			margin-top: 10px;
		}
		.center
		{
            display: flex;
			margin: 0 auto;
			justify-content: center;
			align-items: center;
			max-width: 100%;
		}
		.btn
		{
			text-align: center;
			margin-top: 10px;
		}
		input,select,textarea
		{
		   outline: none;
		}
		.error
		{
			   display:block;
			   margin-top: 10px;
			   color: red;
			   display: none;
			 
		}
        select
		{
			width: 100px;
		}
		#success        /*  //from the postdata*/
		{
			text-align: center;
			color: green;
			font-size: 20px;

		}


	</style>
</head>
<body cz-shortcut-listen="true">
	<div class="center">
		<form method="post">
			<h1>Personal Details</h1>
	<?php
		$id=isset($_GET['id'])? $_GET['id']:"0";
		// echo $id;
		// if($id){
			$query="SELECT * FROM tbl_personal_detail where user_id=$id";
			$result = $conn->query($query);
			$userdata = $result->fetch_assoc();
			
		
		// }
		?>

<div>
			<label>First Name</label>
			<input type="text" name="firstname" id="firstname" value="<?php echo(isset($userdata['user_first_name'])? $userdata['user_first_name']:"");?>">
			<span id="error-data-first"></span>
				
</div>
<div>
			<label>Last Name</label>
			<input type="text" name="lastname" id="lastname" value="<?php echo(isset($userdata['user_last_name'])? $userdata['user_last_name']:"");?>">
			<span id="error-data-last"></span>
				
</div>
<div>
			<label>Email</label>
			<input type="text" name="email" id="email" value="<?php echo(isset($userdata['usser_email'])? $userdata['usser_email']:"");?>">
			<span id="error-data-email"></span>
				
			
</div>
<div>
				
			<label>Gender</label>
			<?php if($userdata['user_gender']==1){?>
				<input type="radio" name="gender" checked=checked value="1" id="male">male
				
			<?php } else{?>
				<input type="radio" name="gender"  value="1" id="male">male
			
			<?php }?>
			<?php if($userdata['user_gender']==2){?>
				<input type="radio" name="gender" checked=checked value="2" id="female">female
				
			<?php } else{?>
				<input type="radio" name="gender"  value="2" id="female">female
			
			<?php }?>
			
			
			<span id="error-data-gender"></span>
				
</div>
<div>
			<label>Mobile Number</label>
			<input type="text" name="number" id="number" value="<?php echo(isset($userdata['user_mobile_no'])? $userdata['user_mobile_no']:"");?>">
			<span id="error-data-number"></span>
				
				
</div>
<div>
			<label>Address1</label>
			<textarea name="address1" id="address1" ><?php echo(isset($userdata['user_addr1'])? $userdata['user_addr1']:"");?></textarea>
			<span id="error-data-address1"></span>
				
</div>
 <div>
			<label>Address2</label>
			<textarea name="address2" id="address2"><?php echo(isset($userdata['user_addr2'])? $userdata['user_addr2']:"");?></textarea> 
			<span id="error-data-address2"></span>
				
</div> 

<div>
		<label>Country</label>
			<select name="country" id="country">
			 <option value="">Select</option>
			 <?php
			$sql = "SELECT ctry_id, ctry_name  FROM tbl_country";
			$result = $conn->query($sql);
				
			if ($result->num_rows > 0) {
				  // output data of each row
				 while($row = $result->fetch_assoc()) {
					 if($userdata['user_ctry_id']==$row['ctry_id']){
					echo '<option selected="selected" value="'.$row["ctry_id"].'">'.$row["ctry_name"].'</option>';
				}
				else{
					echo '<option value="'.$row["ctry_id"].'">'.$row["ctry_name"].' </option>';

				}
			}
		}  
			?>
			</select>	
			<span id="error-data-country"></span>	
</div>	
<div>
			<label>State</label>
			<select name="state" id="state">
			<option value="">Select</option>
			<?php
			$sql = "SELECT stat_id, stat_name  FROM tbl_state";
			$result = $conn->query($sql);
				
			if ($result->num_rows > 0) {
				  // output data of each row
				 while($row = $result->fetch_assoc()) {
					 if($userdata['user_stat_id']==$row['stat_id']){
					echo '<option selected="selected" value="'.$row["stat_id"].'">'.$row["stat_name"].'</option>';
				}
				else{
					echo '<option value="'.$row["stat_id"].'">'.$row["stat_name"].' </option>';

				}
			}
		} 
			?>


			</select>	
			<span id="error-data-state"></span>	
</div>	
<div>
			<label>City</label>
			<input type="text" name="city" id="city" value="<?php echo(isset($userdata['user_city'])? $userdata['user_city']:"");?>">
			<span id="error-data-city"></span>
				
</div>
<div>
			<label>Pincode</label>
			<input type="text" name="pincode" id="pincode" value="<?php echo(isset($userdata['user_pincode'])? $userdata['user_pincode']:"");?>">
			<span id="error-data-pincode"></span>
				
				
</div>
			<div class="btn">
				<input type="submit" name="submit" value="Submit" id="btn">
			</div>
			<input type="hidden" name="userid" id="userid" value="<?php echo $id;?>">
		</form>
	</div>
	<div id="successdiv"></div>
	
	<script>
		$(document).ready(function(){
			$( "#country" ).change(function() {
				var country=$("#country").val();

  			// alert( country );
			  var request = $.ajax({
									url: "ajaxstate.php",
									method: "POST",
									data: { id : country },
									dataType: "html",
									success: function(result){
									$("#state").html(result);
            						}
      
								});
							});



                        $("form").submit(function(){

					var firstname=$("#firstname").val();
                    var lastname=$("#lastname").val();
                    var email=$("#email").val();
                    var address1=$("#address1").val();
                    var address2=$("#address2").val();
					var number=$("#number").val();
                    var pincode=$("#pincode").val();
                    var gender= $("input[name='gender']:checked").val();
                    var city=$("#city").val();
                    var state=$("#state").val();
                    var country=$("#country").val();
					

					
					var fname = /^[A-Za-z ]+$/;  
							if(firstname==""){
							$("#error-data-first").html("please enter Firstname");
							 }
					
							else if(!fname.test(firstname)){
							$("#error-data-first").html("please enter valid Fistname");
								}
							else{
							$("#error-data-first").html("");
								}

					var lname = /^[A-Za-z ]+$/;
							if(lastname==""){
							$("#error-data-last").html("please enter Lastname");
							}
							else if(!lname.test(lastname)){
							$("#error-data-last").html("please enter valid Lastname");
							}
							else{
								$("#error-data-last").html("");
                         		 }

					var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  
						  if(email==""){
						  $("#error-data-email").html("please enter email");
						  }
						  else if(!mailformat.test(email)){
						  $("#error-data-email").html("please enter  valid email");	
						   }
						  else{
								$("#error-data-email").html("");
								}

					var phonenum= /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;  
							if(number==""){
						 	$("#error-data-number").html("please enter number");
                            }
							else if(!phonenum.test(number)){
								$("#error-data-number").html("please enter  valid number");	
							}
							else{
								$("#error-data-number").html("");

							}

					var pin= /^[1-9][0-9]{5}$/;  
							if(pincode==""){
						 	$("#error-data-pincode").html("please enter pincode");
                            }
							else if(!pin.test(pincode)){
								$("#error-data-pincode").html("please enter  valid pincode");	
							}
							else{
								$("#error-data-pincode").html("");

							}
						
						 if(address1==""){
						$("#error-data-address1").html("please enter address1");
                        	 }
							 else{
							$("#error-data-address1").html("");
								}

						if(address2==""){
						$("#error-data-address2").html("please enter address2");
                        	 }
							 else{
							$("#error-data-address2").html("");
								}
					 
					 
						
						$("#error-data-gender").html("");
						if (gender === undefined || gender === null) {
						$("#error-data-gender").html("please enter gender");

					}

					var cityname = /^[A-Za-z ]+$/;  
							if(city==""){
							$("#error-data-city").html("please enter city");
							 }
					
							else if(!cityname.test(city)){
							$("#error-data-city").html("please enter valid city");
							}
							else{
							$("#error-data-city").html("");
								}
								
								

					if(state==""){
						$("#error-data-state").html("please enter state");
                                }
						else{
								$("#error-data-state").html("");

								}

					if(country==""){
						$("#error-data-country").html("please enter country");
                                }
					else{
						$("#error-data-country").html("");

								}
								
			  		 $.ajax({
									url: "save.php",
									method: "POST",
									data: { firstname:firstname,
											lastname:lastname,
											email:email,
											address1:address1,
											address2:address2,
											number:number,
											pincode:pincode,
											gender:gender,
											city:city,
											state:state,
											country:country,
											userid:$("#userid").val()
											 },
									dataType: "json",

								success: function(result){
									if (result.status==1){
									$("#successdiv").html(result.messege);
									window.location="index.php";
									// alert(result.status);

											}
									if(result.status==0){
									$("#success").html(result.messege);

											}
											
            						}
      
								});
							
				return false;

						});
                });


</script>
</body>
</html>