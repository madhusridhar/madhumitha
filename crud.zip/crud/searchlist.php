<?php
include("connection.php");
$country=$_POST['country'];
$state=$_POST['state'];
$input=$_POST['input'];

        $sql="SELECT * from tbl_personal_detail 
			    inner join tbl_country on user_ctry_id = ctry_id 
                inner join tbl_state on user_stat_id=stat_id  WHERE 1 = 1  ";
              
        if($country!=""){
            $sql .= " AND ctry_id =".$country ;
        }
        if($state!=""){
            $sql .= " AND stat_id =".$state ;
        }
        if($input!=""){
            $sql .= " AND ( user_first_name LIKE '" .$input ."%' ||
                            user_last_name LIKE '" .$input ."%' ||
                            usser_email LIKE '" .$input ."%' ||
                            user_gender LIKE '" .$input ."%' ||
                            user_mobile_no LIKE '" .$input ."%' ||
                            user_addr1 LIKE '" .$input ."%' ||
                            user_addr2 LIKE '" .$input ."%' ||
                            ctry_name LIKE '" .$input ."%' ||
                            stat_name LIKE '" .$input ."%' ||
                            user_city LIKE '" .$input ."%' ||
                            user_pincode LIKE '" .$input ."%'
                            ) ";


            
        }
       
        $result = $conn->query($sql);

                while($tr = $result->fetch_assoc()){
                    ?>
                        <tr>
                           <td><input type="checkbox" ></td>
                           <td><?php echo $tr['user_first_name'] ?></td>
                              <td><?php echo $tr['user_last_name'] ?></td>
                              <td><?php echo $tr['usser_email'] ?></td>  	
                              <td><?php
                               
                               if ($tr['user_gender']== '2'){
                                   echo "FEMALE";
                                   }
                               else { 
                           echo "MALE";
                       } ?>
           
                           <td><?php echo $tr['user_mobile_no'] ?></td>
                              <td><?php echo $tr['user_addr1'] ?></td> 
                              <td><?php echo $tr['user_addr2'] ?></td>
                              <td><?php echo $tr['ctry_name'] ?></td>
                              <td><?php echo $tr['stat_name'] ?></td> 
                              <td><?php echo $tr['user_city'] ?></td>
                              <td><?php echo $tr['user_pincode'] ?></td>
                              <td><a href="add.php?id=<?php echo $tr['user_id'] ?>">Edit </a></td>
                              <td><a class="delete" href="delete.php?id=<?php echo $tr['user_id'] ?>">delete</a></td>
                              
                       </tr> 
                      <?php }
                   ?>

              
    