<?php
include("connection.php");

// if(isset($_POST['submit'])){

$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$email=$_POST['email'];
$address1=$_POST['address1'];
$address2=$_POST['address2'];
$number=$_POST['number'];
$pincode=$_POST['pincode'];
$gender=$_POST['gender'];
$city=$_POST['city'];
$state=$_POST['state'];
$country=$_POST['country'];
$userid=$_POST['userid'];
// die;

if( $userid == 0 ) {

    $sql="INSERT INTO tbl_personal_detail(user_first_name,user_last_name,usser_email,user_gender,user_mobile_no,user_addr1,user_addr2,user_ctry_id,user_stat_id,user_city,user_pincode)VALUES('$firstname','$lastname','$email','$gender','$number','$address1','$address2','$country','$state','$city','$pincode')";


    $conn->query($sql);
    $last_id = $conn->insert_id;
    if($last_id ){
        echo json_encode(array("status"=>1,"message"=>" Data  inserted Successfully"));
    } else {
        echo json_encode(array("status"=>0,"message"=>"Data  not inserted successfully"));
    }

} else {

    $sql="UPDATE tbl_personal_detail 
    set user_first_name='$firstname',
    user_last_name='$lastname',
    usser_email='$email',
    user_gender='$gender',
    user_mobile_no='$number',
    user_addr1='$address1',
    user_addr2='$address2',
    user_ctry_id='$country',
    user_stat_id='$state',
    user_city='$city',
    user_pincode='$pincode' 
    WHERE user_id='$userid'";
//    echo $sql;die;
    $update= $conn->query($sql);
    if($update){
        echo json_encode(array("status"=>1,"message"=>" Data  updated Successfully"));
    }else{
        echo json_encode(array("status"=>0,"message"=>"Data  not updated successfully"));
    }
    
    }?>

