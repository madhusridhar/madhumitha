<!DOCTYPE html>
<!-- saved from url=(0022)http://localhost/task/ -->
<html><head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<!-- <link rel="stylesheet" id="font-awesome-style-css" href="./list_files/bootstrap3.min.css" type="text/css" media="all"> -->
	<!-- <script type="text/javascript" charset="utf8" src="./list_files/jquery-1.8.2.min.js.download"></script> -->

	<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
	<title>Home</title>
	<style type="text/css">
		*
		{
			margin: 0;
			padding: 0;
		}
		.head
		{
			height: 50px;
			background-color: #3492eb;
		}
		.pd_div
		{
		    background-color: #e7e7e7;
		    height: 50px;
		    display: flex;
		    justify-content: space-between;
		    align-content: center;
		    align-items: center;	   
		}
		.add_user
		{
			 text-decoration: none;
			 background-color: #14c71a;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
		}
		.heading
		{
			margin-left: 20px;
			font-size: 24px;
			font-weight: bold;
		}
		.filter_search
		{
            height: 80px;
            /*background-color: #abdc;*/
            display: flex;
            align-items: center;
            float: right;
            margin-right: 20px;


            /*justify-content: space-between;*/

		}
		.search
		{
			outline: none;
			padding: 5px 8px;
		}
		.search_btn
		{
			padding: 5px 8px;
			cursor: pointer;
		}
		.search_country,.search_state
		{
				padding: 7px 8px;
				cursor: pointer;
				width: 100px;
				outline: none;
		}
		.dlt_btn{
			cursor: pointer;
			text-decoration: none;
			 background-color: red;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
			
		}
		.clear
		{
			clear: both;
			display: flex;
			justify-content: center;
		}
		#list 
		{
		  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		  border-collapse: collapse;
		  width: 100%;
        }

        #list td, #list th 
        {
		  border: 1px solid #ddd;
		  padding: 8px;
		  text-align: center;
        }	

        #list th 
        {
          text-align: center;
        }

        #list tr:nth-child(even)
        {
        	background-color: #f2f2f2;
        }

		#list tr:hover 
		{
			background-color: #ddd;
			cursor: pointer;
		}

		#list th 
		{
		  padding-top: 12px;
		  padding-bottom: 12px;
		  text-align: center;
		  background-color: #4CAF50;
		  color: white;
		}
		.pagelist
		{
             text-decoration: none;
             background-color: #182c4d;
             color: white;
             padding: 3px 10px;
		}
	
	</style>
</head>
<body cz-shortcut-listen="true">
	<div class="head">
		
	</div>

	<div class="pd_div">
		<p class="heading">Personal Details</p>
		<a class="add_user" href="http://localhost/demo/crud/add.php">Add User</a>
	</div>

	<div class="filter_search">
		<div class="search_right">
			<select class="search_country" id="search_input_country" name="">
				<option value="">Select</option>
			<?php
				include("connection.php");

			$sql = "SELECT ctry_id, ctry_name  FROM tbl_country";
			$result = $conn->query($sql);
				
			if ($result->num_rows > 0) {
				  // output data of each row
				 while($row = $result->fetch_assoc()) {
					 if($userdata['user_ctry_id']==$row['ctry_id']){
					echo '<option selected="selected" value="'.$row["ctry_id"].'">'.$row["ctry_name"].'</option>';
				}
				else{
					echo '<option value="'.$row["ctry_id"].'">'.$row["ctry_name"].' </option>';

				}
			}
		}  
			?>
			
	
</select>

			<select name="state" id="state" class="search_state">
			       <option value="">Select</option>
		<?php
			 include("connection.php");

			$sql = "SELECT stat_id, stat_name  FROM tbl_state";
			$result = $conn->query($sql);
				
			if ($result->num_rows > 0) {
				  // output data of each row
				 while($row = $result->fetch_assoc()) {
					 if($userdata['user_stat_id']==$row['stat_id']){
					echo '<option selected="selected" value="'.$row["stat_id"].'">'.$row["stat_name"].'</option>';
				}
				else{
					echo '<option value="'.$row["stat_id"].'">'.$row["stat_name"].' </option>';

				}
			}
		} 
			?>


		</select>
			<input type="text" class="search" id="search_input" name="" placeholder="Search">
			<button class="search_btn" id="search_btn" name="search">Search</button>
			<a class="dlt_btn" id="blkdelete">Delete</a>
			
		

	     </div>
	</div>

<div class="clear">
	 </div>


<?php
	include("connection.php");

	$sql="SELECT * from tbl_personal_detail 
			inner join tbl_country on user_ctry_id = ctry_id 
			inner join tbl_state on user_stat_id=stat_id order by user_id ";
	$result = $conn->query($sql);

?>

<div id="target-content"><table id="list">
	    <thead>
            <tr>
				<th><input type="checkbox" class= "checked_all"></th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Email</th>
				<th>Gender</th>
				<th>Mobile Number</th>
				<th>Address 1</th>
				<th>Address 2</th>
				<th>Country</th>
				<th>State</th>
				<th>City</th>
				<th>Pincode</th>
				<th>Edit</th>
				<th>Delete</th>
			</tr>
		</thead>
		
	   <tbody id="tabledata"> 
	   <?php
	   while($tr = $result->fetch_assoc()){
		?>
		     <tr>
		    	<td><input type="checkbox" class="checkbox"  value="<?php echo $tr['user_id']?>"></td>


	<script type="text/javascript">

        				
    </script>

				<td><?php echo $tr['user_first_name'] ?></td>
		   		<td><?php echo $tr['user_last_name'] ?></td>
		   		<td><?php echo $tr['usser_email'] ?></td>  	
				   <td><?php
				    
    				if ($tr['user_gender']== '2'){
        				echo "FEMALE";
    					}
    				else { 
        		echo "MALE";
    		} ?>

				<td><?php echo $tr['user_mobile_no'] ?></td>
		   		<td><?php echo $tr['user_addr1'] ?></td> 
		   		<td><?php echo $tr['user_addr2'] ?></td>
		   		<td><?php echo $tr['ctry_name'] ?></td>
		   		<td><?php echo $tr['stat_name'] ?></td> 
		   		<td><?php echo $tr['user_city'] ?></td>
		   		<td><?php echo $tr['user_pincode'] ?></td>
		   		<td><a href="add.php?id=<?php echo $tr['user_id'] ?>">Edit </a></td>
		   		<td><a href="#" class="delete" onclick="deletefun(<?php echo $tr['user_id']?>)">delete</a></td>
				   

		   		<!-- <td><img src="./list_files/delete.png" height="20px" width="20px"></td> -->
		    </tr> 
		   <?php }
		   ?>

 </tbody></table>
	 <div align="center">
	<ul class="pagination text-center" id="pagination">
            <li class="active" id="1"><a href="http://localhost/task/pagination.php?page=1">1</a></li> 
						
			<li id="2"><a href="http://localhost/task/pagination.php?page=2">2</a></li>
					
			<li id="3"><a href="http://localhost/task/pagination.php?page=3">3</a></li>
					
			<li id="4"><a href="http://localhost/task/pagination.php?page=4">4</a></li>
					
  
</ul></div>


</div>
	
<script type="text/javascript">
		$(document).ready(function() {

						$('.checked_all').on('change', function() {     
               			 $('.checkbox').prop('checked', $(this).prop("checked"));              
        					});
        //deselect "checked all", if one of the listed checkbox product is unchecked amd select "checked all" if all of the listed checkbox product is checked
        		$('.checkbox').change(function(){
					 //".checkbox" change 
            		if($('.checkbox:checked').length == $('.checkbox').length){
                  	 $('.checked_all').prop('checked',true);
           		 }else{
                  	 $('.checked_all').prop('checked',false);
            }
        });

			$('#blkdelete').click(function(){
 			if(confirm("Are you sure to delete?"))
 			{
 				var id = [];
				$(':checkbox:checked').each(function(i){
 				id[i] = $(this).val();
			 }); 
			 //alert(id); return false;
 			if(id.length === 0)
		 	{
 			alert("Please Select Checkbox");
 			}
 	else
 		{
 		$.ajax({
 							url:"delete.php",
 							method: "POST",
 							data:{id:id},
 							success:function()
							{
								window.location="index.php";
 							
 							}
 				});
							 }
			 }
 			});



	$( "#search_input_country" ).change(function() {
		var country=$("#search_input_country").val();

	
		 $.ajax({
							url: "ajaxstate.php",
							method: "POST",
							data: { id : country },
							dataType: "html",
							success: function(result){
								$("#state").html(result);
							}

		});							
				 
	});

	$( "#search_btn" ).click(function() {
		
						var country=$("#search_input_country").val();
						// alert( country );
						var state=	$("#state").val();
						var input=	$("#search_input").val();
						$.ajax({ 
									url: "searchlist.php",
									method: "POST",
									data: { country: country,
											state:state,
											input:input
											},
									dataType: "html",
									success: function(result){
									$("#tabledata").html(result);
            						}
      
								});


});
	// 			$(document).on('click','.delete',function(e){
	// 				// alert("test");
					
	// });

	

});  //ready function end

function deletefun(id)
	{
		var id=id;
				// alert(id);
				if(confirm("Are  you want to delete")){

					$.ajax({ 
						url: "delete.php",
						method: "POST",
						data: {id:id},
						dataType: "html",
						success: function(result){
							window.location="index.php";
						// alert("Record deleted successfully");
						}

					});

		
			}
	}
						
        </script>

</body>
</html>