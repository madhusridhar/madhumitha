<?php
//echo"Test"; die;
include("connection.php");
$sql = "SELECT * from tbl_country inner join tbl_state on tbl_country.ctry_id=tbl_state.stat_ctry_id where  stat_ctry_id=".$_POST['id'];
 //echo $sql;die;
$result = $conn->query($sql);

if (mysqli_num_rows($result) > 0) {
    // ceho '<option value="'.$row[""]>''</option>';
   echo ' <option value="">Select</option>';


    // output data of each row
    while($row = $result->fetch_assoc()) {
    echo '<option value="'.$row["stat_id"].'">'.$row["stat_name"].'</option>';
    }
}

?>