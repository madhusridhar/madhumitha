<?php
include("../connection.php");
$id= is_array($_POST['id']) ? implode(',',$_POST['id']) : $_POST['id']; 

$sql ="DELETE FROM tbl_country WHERE ctry_id IN(".$id.")";;
// echo $sql;
 $conn->query($sql);
?>