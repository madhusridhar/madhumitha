<?php
				include("../connection.php");
?>

<!DOCTYPE html>
<!-- saved from url=(0022)http://localhost/task/ -->
<html><head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<!-- <link rel="stylesheet" id="font-awesome-style-css" href="./list_files/bootstrap3.min.css" type="text/css" media="all"> -->
	<!-- <script type="text/javascript" charset="utf8" src="./list_files/jquery-1.8.2.min.js.download"></script> -->

	<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
	<title>Home</title>
	<style type="text/css">
		*
		{
			margin: 0;
			padding: 0;
		}
		.head
		{
			height: 50px;
			background-color: #3492eb;
		}
		.pd_div
		{
		    background-color: #e7e7e7;
		    height: 50px;
		    display: flex;
		    justify-content: space-between;
		    align-content: center;
		    align-items: center;	   
		}
		.add_user
		{
			 text-decoration: none;
			 background-color: #14c71a;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
		}
		.heading
		{
			margin-left: 20px;
			font-size: 24px;
			font-weight: bold;
		}
		.filter_search
		{
            height: 80px;
            /*background-color: #abdc;*/
            display: flex;
            align-items: center;
            float: right;
            margin-right: 20px;


            /*justify-content: space-between;*/

		}
		.search
		{
			outline: none;
			padding: 5px 8px;
		}
		.search_btn
		{
			padding: 5px 8px;
			cursor: pointer;
		}
		.search_country,.search_state
		{
				padding: 7px 8px;
				cursor: pointer;
				width: 100px;
				outline: none;
		}
		.dlt_btn{
			cursor: pointer;
			text-decoration: none;
			 background-color: red;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
			
		}
		.clear
		{
			clear: both;
			display: flex;
			justify-content: center;
		}
		#list 
		{
		  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		  border-collapse: collapse;
		  width: 100%;
        }

        #list td, #list th 
        {
		  border: 1px solid #ddd;
		  padding: 8px;
		  text-align: center;
        }	

        #list th 
        {
          text-align: center;
        }

        #list tr:nth-child(even)
        {
        	background-color: #f2f2f2;
        }

		#list tr:hover 
		{
			background-color: #ddd;
			cursor: pointer;
		}

		#list th 
		{
		  padding-top: 12px;
		  padding-bottom: 12px;
		  text-align: center;
		  background-color: #4CAF50;
		  color: white;
		}
		.pagelist
		{
             text-decoration: none;
             background-color: #182c4d;
             color: white;
             padding: 3px 10px;
		}
	
	</style>
</head>
<body cz-shortcut-listen="true">
	<div class="head">
		
	</div>

	<div class="pd_div">
		<p class="heading">Country Details</p>
		<a class="add_user" href="addcountry.php">Add Country</a>
	</div>

	<div class="filter_search">
		<div class="search_right">
			
			
			<input type="text" class="search" id="search_input" name="" placeholder="Search">
			<button class="search_btn" id="search_btn" name="search">Search</button>
			<a class="dlt_btn" id="blkdelete">Delete</a>
			
		

	     </div>
	</div>

<div class="clear">
	 </div>


<?php
	// include("connection.php");

	$sql="SELECT * from tbl_country  order by ctry_id ";
	$result = $conn->query($sql);
	$row_count = mysqli_num_rows($result);

?>

<div id="target-content"><table id="list">
	    <thead>
            <tr>
				<th><input type="checkbox" class= "checked_all"></th>
				
				<th>Country</th>
				<th>Edit</th>
				<th>Delete</th>
			</tr>
		</thead>
		
	   <tbody id="tabledata"> 
	   <?php
	   while($tr = $result->fetch_assoc()){
		?>
		     <tr>
		    	<td><input type="checkbox" class="checkbox"  value="<?php echo $tr['ctry_id']?>"></td>



				
		   		<td><?php echo $tr['ctry_name'] ?></td>
		   		
		   		<td><a href="addcountry.php?id=<?php echo $tr['ctry_id'] ?>">Edit </a></td>
		   		<td><a href="#" class="delete" onclick="deletefun(<?php echo $tr['ctry_id']?>)">delete</a></td>
				   

		   		<!-- <td><img src="./list_files/delete.png" height="20px" width="20px"></td> -->
		    </tr> 
		   <?php }
		   ?>

 </tbody></table>
	


</div>
	
<script type="text/javascript">
		$(document).ready(function() {

						$('.checked_all').on('change', function() {     
               			 $('.checkbox').prop('checked', $(this).prop("checked"));              
        					});
        
        		$('.checkbox').change(function(){
					 
            		if($('.checkbox:checked').length == $('.checkbox').length){
                  	 $('.checked_all').prop('checked',true);
           		 }else{
                  	 $('.checked_all').prop('checked',false);
            }
        });
//bulk delete
			$('#blkdelete').click(function(){
 				var id = [];
				$(':checkbox:checked').each(function(i){
 				id[i] = $(this).val();
			 }); 
			 //alert(id); return false;
 			if(id.length === 0)
		 	{
 			alert("Please Select Checkbox");
			 return false;
 			}
			 
	 if(confirm("Are you sure to delete?"))
 		{
 		$.ajax({
 							url:"deletecountry.php",
 							method: "POST",
 							data:{id:id},
 							success:function()
							{
								window.location="countrylist.php";
 							
 							}
 				});//ajax ends
						}//if ends
			 });//click ends
 			


	$( "#search_btn" ).click(function() {
		
						// var country=$("#search_input").val();
						// alert( country );
						// var state=	$("#state").val();
						var input=	$("#search_input").val();
						$.ajax({ 
									url: "searchlistctry.php",
									method: "POST",
									data: {
											input:input
											},
									dataType: "html",
									success: function(result){
									$("#tabledata").html(result);
            						}
      
								});//ajax ends


});//click ends
	// 			$(document).on('click','.delete',function(e){
	// 				// alert("test");
					
});  //ready ends



//delete

function deletefun(id)
	{
		var id=id;
				// alert(id);
				if(confirm("Are  you want to delete")){

					$.ajax({ 
						url: "deletecountry.php",
						method: "POST",
						data: {id:id},
						dataType: "html",
						success: function(result){
							window.location="countrylist.php";
						// alert("Record deleted successfully");
						}

					});

		
			}
	}
						
        </script>

</body>
</html>