<?php
include("../connection.php");

// if(isset($_POST['submit'])){


$country=$_POST['country'];
 $userid=$_POST['ctry_id'];
// die;

if( $userid == 0 ) {

    $sql="INSERT INTO tbl_country(ctry_name)VALUES('$country')";


    $conn->query($sql);
    $last_id = $conn->insert_id;
    if($last_id ){
        echo json_encode(array("status"=>1,"message"=>" Data  inserted Successfully"));
    } else {
        echo json_encode(array("status"=>0,"message"=>"Data  not inserted successfully"));
    }

} else {

    $sql="UPDATE tbl_country
    set 
    ctry_name='$country'
    
     WHERE ctry_id='$userid'";
//    echo $sql;die;
    $update= $conn->query($sql);
    if($update){
        echo json_encode(array("status"=>1,"message"=>" Data  updated Successfully"));
    }else{
        echo json_encode(array("status"=>0,"message"=>"Data  not updated successfully"));
    }
    
    }
    ?>

