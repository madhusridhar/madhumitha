<?php
include("../connection.php");
// $country=$_POST['country'];
// $state=$_POST['state'];
$input=$_POST['input'];

        $sql="SELECT * from  tbl_country  WHERE 1 = 1  ";
              
                // inner join tbl_state on user_stat_id=stat_id  
      
        
        // if($state!=""){
        //     $sql .= " AND stat_id =".$state ;
        // }
        if($input!=""){
            $sql .= " AND (
                            ctry_name LIKE '" .$input ."%' 
                            
                            ) ";


            
        }
       
        $result = $conn->query($sql);
        $row_count = mysqli_num_rows($result);
        echo $row_count;
        if($row_count==0){?>
<tr>
<td colspan="4">No data available
                    </td>
</tr>
<?php
}else{

                while($tr = $result->fetch_assoc()){
                    ?>
                        <tr>
                           <td><input type="checkbox" ></td>
                           
                              <td><?php echo $tr['ctry_name'] ?></td>
                             
                              <td><a href="addcountry.php?id=<?php echo $tr['ctry_id'] ?>">Edit </a></td>
                              <td><a class="delete" href="delete.php?id=<?php echo $tr['ctry_id'] ?>">delete</a></td>
                              
                       </tr> 
                      <?php }
        }
                   ?>

              
    